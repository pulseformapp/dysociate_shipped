# dλsociate website release

The Cloudflare static asset Worker serves the public homepage and release files. The live Worker serves `/t/*` and `/api/v1/*` separately. The website uses direct downloads and includes matching GPL source and SHA-256 checksums. The first release has no payment step.

Build the Windows package with `python_pagebuilder/build_distribution.ps1 -WebRelease`. The installer uses a one-directory PyInstaller runtime and Inno Setup compression. The public source archive accompanies the installer on the download site. Windows installation is per-user and offers optional desktop and HTML **Open with** integration. Use `-InnoCompiler` to point at Inno Setup 6 and `-WebView2Sdk` when using an existing SDK.

Build Android with `dysociate_android/build.ps1`, an explicit release keystore and alias, and an installed SDK and JDK. `-KeystorePasswordEnvironment` can name the process environment variable containing the keystore password. Preserve the production signing key for later upgrades. Back it up privately. Source and site assets contain only the signed APK and public release material. Previous preview users should first export local work before replacing a build signed with a different key.

Run `python dysociate_placeholder/package_release.py <staged-windows-package> <signed-apk> 1.8.8` from the parent of the source folders. Verify a clean install, download hashes, and the agreement and creation flow. Check both Worker configs with Wrangler dry runs. Files served directly from Cloudflare static assets must each fit within 25 MiB.

Deploy the live Worker using `dysociate_live/wrangler.jsonc` and the homepage using `dysociate_placeholder/wrangler.jsonc`. Preserve the existing production invite keys and origin. Phone push remains on its separate pilot until physical device verification. After deployment, fetch the three release assets by HTTPS and compare their hashes against the manifest. Check the public browser editor and a live link through the normal homepage flow.
