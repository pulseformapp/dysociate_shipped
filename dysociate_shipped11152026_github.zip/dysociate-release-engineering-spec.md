# dλsociate Release Engineering Specification

**Draft for review · November 14, 2026**

## 1. Product contract

Someone creates a live thread, sends its link, and the recipient opens it and joins the conversation. Wild West threads accept anyone with the link. Locked threads require the existing passkey or creator approval. Admitted guests have the same ability to read, post, reply, and Like. People can delete their own posts. Deletion leaves a marker so the replies and their context survive.

Windows and Android support both live conversations and offline HTML. A saved copy opens without connectivity, accepts local replies, and can be shared as one file. Its local edits stay in that copy. On iPhone, the live experience ships through the browser. A Home Screen web app adds phone notifications for people who opt in.

The first public release is free on the web, Windows, and Android. On dysociate.org, **Create live thread** opens the web app and two download buttons serve the official Windows installer and Android APK. Corresponding source, checksums, and installation help are available from the site. Cloudflare Free static assets serve files up to 25 MiB each. If a release artifact exceeds the limit, the website can link directly to it on GitHub Releases.

The native apps include their existing offline HTML workflow. A live browser export, hosted document uploads, and creator dashboard are candidates for a later subscription purchased through dysociate.org. Billing and entitlement design require a separate discussion after the free release.

The existing editors and shared live viewer are the release foundation. Continue to keep transport, state, and presentation separate so work on the custom C++ interface can proceed later. Final visual polish starts when Luna explicitly approves it. Nonprofit setup follows product development.

## 2. Baseline and phase order

Phase 11 build **1.8.6** is the regression baseline. Its release notes document Windows and Android in-app live viewing, a 54-post export with a deleted parent and older photo, Android emulator offline reply and share, and Windows reopening the resulting file. They record exact MP4 export bytes in a separate test. The APK there uses the test signing key. [Phase 11 evidence](dysociate_live_phase11/README.md)

The Worker uses per-thread SQLite Durable Objects, versioned HTTP commands, WebSocket updates, and anonymous ownership. Production targets `/t/*` and `/api/v1/*` and enables browser creation, locked threads, photos, and reels. Phone push stays in the pilot through physical iPhone and Android verification. Treat the config files as deployment intent and verify effective features on the release endpoint. [Server and protocol](dysociate_live/README.md) · [Production config](dysociate_live/wrangler.jsonc) · [Pilot config](dysociate_live/wrangler.pilot.jsonc)

| Phase | Deliverable | Exit evidence |
| --- | --- | --- |
| 12A | Release baseline, reply groups, and Likes | Old links, clients, and HTML fixtures pass. Two isolated clients agree on history and Likes after reconnect. |
| 12B | Following and opt-in Web Push | A real iPhone and Android receive test replies with the web app in the background. Tapping opens the right post. Locked admission stays enforced. |
| Free website release | Official web app and native downloads on dysociate.org | The production creator enforces the agreements. Each public download matches the tested installer or signed APK, with source and checksums alongside it. |
| Later subscription | Browser export, bounded file uploads, and creator tools | Define pricing and subscriptions on dysociate.org after the free release. |
| Final UI approval | Luna reviews the working Windows, Android, and mobile browser flows included in the candidate | Explicit approval precedes the final visual polish pass. Bugs that prevent using or testing the flows can be fixed during their feature phases. |
| Release candidate | Distribution, recovery rehearsal, and release evidence | Free release passes its own gates. Paid uploads can launch independently when their gates pass. |

The first implementation phase is 12A. Run a small HTTPS push feasibility check early enough to uncover iPhone installation or routing problems before committing the notification UI.

## 3. Reply groups and Likes

### Website agreements

- Open **License Agreement**, then **Karmic Law**, before revealing the website editor. Use the app wording and **~ as above so below ~**. Reveal **I agree** at the end of each step and keep **Decline** available. Returning creators reuse their anonymous session's acceptance for the current wording.
- Recipients can open a shared link and read once they meet the existing access rules. Show both agreements at their first post or reply on each thread. Remember acceptance by thread and anonymous browser identity. Reopening the same thread reuses acceptance. Declining preserves the draft and leaves the thread readable. After accepting, the writer returns to the draft and can send it. A browser creator's accepted terms also cover the thread they just created.
- Enforce current acceptance on the corresponding browser API writes. When the wording changes or a browser session is cleared, show the agreements again. Test direct editor navigation, both refusal points, reopening, a second invite, and a locked member's first reply.

### Reply groups

- Order top-level posts by existing creation sequence. Show **View N replies** with the count of visible replies across the branch, including replies outside the currently loaded page. Expand a branch below its root with one vertical rail and one indentation level. Each reply keeps its direct parent and links to it via **Reply to [name]**. Include a short plain-text excerpt when available. Use **Deleted post** for a removed parent.
- Use the existing parent IDs to derive a branch’s root. Add a paged root/reply query or compatible additions to history where necessary to produce accurate counts, reach older ancestors, and open a direct post target. Verify a target belongs to the current thread before returning its path. Keep branch ordering by creation sequence. Treat unread and newly arrived replies as changes in place so readers keep their scroll position and draft.
- Opening a notification or tapping a parent link loads the needed page, opens the branch, and focuses the post or deletion marker. The composer retains its selected reply target across a reconnect. If the target is unavailable, show that state and keep the draft.

### Likes

- Store one Like per `(postId, threadScopedActorId)`. A desired-state command sets or clears the Like and returns the canonical count, viewer state, and reaction version. Repeated requests for the same state are harmless. Keep one write in flight per post and disable the button while it is pending. Give each write an operation ID and actor revision so an uncertain retry cannot undo a newer change. The server authorizes every read and write and applies a separate reaction rate limit. Deleted posts lose the action and cannot acquire Likes.
- Keep reactions out of the existing post sequence and the 2,000-mutation cap. Use a separate per-post reaction version and a socket invalidation for new clients. Reload counts and viewer state in batches on reconnect or when opening a previously unloaded branch. Keep older clients' `post.changed` and catch-up behavior compatible. Expose counts and the viewer's state, with no list of individual reactors at launch.
- Use an accessible button with a visible count and a pressed state. Preserve chronological order. Likes produce no push events and the offline HTML release carries conversation history without adding offline reactions.

**Acceptance.** Test a parent older than the first history page, a long reply chain, a deleted root, collapsed branches receiving new replies, and a notification to an older reply. Test simultaneous Likes by separate sessions, repeated requests, rapid unlike/Like, delete versus Like, and reconnect with missed reaction updates. Assert that none of those operations consume post sequences or reorder the feed.

## 4. Following and phone notifications

### User flow

1. After entering a thread, choose **Follow thread** and select **Replies to me**, **All activity**, or **Mute**. Default to replies to posts authored by the current browser session. A participant can switch to All activity before posting. The permission prompt follows a deliberate tap.
2. On iPhone and iPad running 16.4 or later, guide users from Safari to **Add to Home Screen**, then into the web app to finish following. If the thread is missing from that context, let them paste the original invite once. The Home Screen app may use a separate browser session. Locked threads must complete admission in that session. On Android use a supported browser's Web Push flow. The app viewer can hand off to the system browser for setup. [Apple WebKit](https://webkit.org/blog/13878/web-push-for-web-apps-on-ios-and-ipados/) · [Google Web Push](https://web.dev/articles/push-notifications-overview)
3. Reopen followed threads from **Following** or by tapping an alert. After enrollment, the original message is unnecessary while that device retains access and its subscription. Explain browser permission denial or revocation in place. Keep live updates visible in an open thread even when background notifications are unavailable.

### Service design

- Serve a manifest with a stable app ID and a start page such as `/t/following`. Serve the service worker within `/t/` and scope it to that path. Use the existing Worker route. Cache versioned public assets only if useful. Keep thread pages, invites, APIs, and private media out of service-worker caches. Store followed thread references locally for reopening, and support explicit unfollow and removal.
- Record notification candidates in a bounded outbox in the same transaction as a new post or reply, when the thread has eligible follows. Deliver asynchronously with a Durable Object alarm or a measured equivalent. The foreground posting response is independent of the push provider. Recheck the subscription, notification mode, and thread admission when delivering. Skip the sender and suppress Likes, deletion events, and pending membership requests in the first release.
- Route encrypted Web Push to the browser's verified HTTPS push service using environment-specific VAPID keys. Strictly validate destination hosts, key material, request size, and subscription ownership. Use bounded fan-out, coalesce activity by thread and device, deduplicate using the committed post ID and subscription, and give retry work a short expiry. Remove registrations when the provider reports them gone. Use generic lock-screen copy and an opaque target reference. Recheck access on open. Keep content, invite URLs, push endpoints, and keys out of logs.
- Track delivery attempts and provider responses in aggregate. Provider acceptance is distinct from a notification actually appearing on a device. Measure real-device latency separately. No background polling of threads by phones.

**Acceptance.** Start from a shared message link on an iPhone, add the icon, follow, close the page, lock the phone, post from a second device, and tap through to the exact reply. Repeat in Android Chrome. Cover denial, mute/unfollow, enrollment on a second device, a pending locked member, a browser session that lost access, bursts, transient provider failure, and notification delivery after the original message is gone. While testing basic posting, simulate a completely unavailable push service.

## 5. Paid attachments and offline exports

- Reuse the existing attachment validation and commit flow. For the first release, a post can carry one attachment. Keep photos and recorded MP4 reels on their existing limits. Add a separate document picker for paid uploads with visible accepted types, current limits, and errors that preserve the draft. Start with 1 MiB TXT and PDF and evaluate ZIP up to 2 MiB as a pilot setting. Use a distinct document field or capability negotiation so existing clients continue to interpret the current `media` field as photo or video only. Update the contract and export readers before enabling documents in production. Uploaded video files remain outside the reel flow.
- Validate bytes and type on the server independently of extension. Require valid UTF-8 text for TXT and verify expected signatures and basic structure for PDF and ZIP before serving. ZIP validation never extracts the archive on the service. Reject mismatches and normalize filenames for display and download. Serve documents as downloads with `Content-Disposition: attachment`, `nosniff`, and private caching rules. Apply thread access, post visibility, and retention checks to downloads, including `HEAD`. A retained attachment is available to admitted guests even when its uploader's entitlement has expired.
- Store file metadata and bounded bytes using the existing SQLite attachment model. Apply per-file, per-thread, per-purchaser, and account budgets to both pending and committed documents. Reserve quota before receiving or persisting large bodies. Key reservations and commit reconciliation to the stable upload operation ID. A failed or expired reservation can be released after verifying whether a post committed. Commit the attachment, post, and receipt together in the thread object. Same operation and bytes return the same post after a lost response. Authorization and quota checks run on the server for new writes.
- Extend the Phase 11 exporter to embed eligible document bytes and explicit names in the portable HTML. Downloads from offline copies must work without network access and must remain downloads. Test the exact bytes from the exported file inside Windows and Android. Preserve old files and the locked-copy warning. Budget for base64 expansion and the Android 64 MiB open limit. Check the live snapshot and attachment availability before publishing the export. If a required attachment fails to transfer, keep prior copies and report the incomplete save. A file already expired or withdrawn appears as an unavailable marker. An externally hosted link remains a link and requires connectivity. Verify that supported older exporters either receive a usable fallback or show an upgrade error instead of reporting an incomplete export as complete.
- Allow reports on individual attachments. The operator can disable delivery of the reported file without deleting the post, other people's replies, or the thread. A deleted post loses its attachment. Expiry and removal keep a reasoned placeholder so conversation references still make sense. Recheck availability during download and export. Give attachment availability a revision that can advance even at the thread's posting cap. Previously exported copies remain readable offline.

**Acceptance.** An entitled uploader and an unentitled guest use the same thread. The guest downloads and replies and receives a clear upgrade message when attempting a document upload. Check wrong thread, pending admission, guessed IDs, disguised files, oversized streamed bodies, duplicate operations, interrupted uploads, simultaneous quota use, author deletion, withdrawal, and expiration. Export a mixed thread near the size limit, toggle airplane mode, open it on both apps, and verify TXT/PDF bytes. Add the same tests for ZIP before enabling it.

### API compatibility

Extend the existing v1 schema and fixtures before wiring each feature into a UI. The following commands describe the minimum contract. Check every thread-scoped command against current membership and use the existing typed error envelope. Document validation errors, `403` for a missing upload entitlement, `413` for an oversized file, `429` for a transient limit, and a capacity error with retry guidance where applicable.

| Capability | Minimum response or event |
| --- | --- |
| Load a reply branch or post target | Root ID, direct parent ID, stable page cursor, branch count, and target availability. |
| Set a Like or recover missed changes | Canonical count, viewer state, and reaction revision. Socket notifications only require the post ID and new revision. |
| Follow, change mode, or unfollow | Current mode and subscription state for this device. Each change must be safe to repeat. |
| Attach or download a document | Commit returns the existing post record and stable document metadata. Download authorizes access again and returns bytes or a typed unavailable response. |
| Redeem an upload pass or check status | Effective expiry, entitlement state, and remaining allowance. Keep purchase references out of thread data. |

## 6. Future website subscriptions

- Discuss the payment provider and purchase recovery separately. Keep guest participation anonymous and check creator entitlements server-side. The free release has no subscription surface.
- Proposed lifecycle is `active → expired` or `active → revoked`. Expiration stops new document uploads, and a refund or confirmed revocation disables the upload privilege. Existing posts and replies stay readable. Start the retention discussion with a 90-day download window after an ordinary expiration. Publish the exact dates, renewal behavior, refund handling, and export instructions before taking payments. Quota planning counts retained bytes during that window. Use authenticated status checks, idempotent changes, and a test purchase through recovery before launch.
- Set pricing after measuring storage usage, support workload, and purchaser interest. Keep the corresponding source and license notices with each public build. [Project license](dysociate_live/LICENSE)

## 7. Cloudflare Free operating envelope

Keep the launch on Workers Free with SQLite-backed Durable Objects and R2 disabled. Capture actual account usage across the homepage, API, pilot, and other workloads that share its quotas. Track Worker and Durable Object requests, active duration, SQL reads/writes, stored bytes, pending reservations, and push sends. Free quota exhaustion can cause errors. Set app-level thresholds while there is still headroom for text, access, history, and existing downloads. [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) · [Durable Objects pricing](https://developers.cloudflare.com/durable-objects/platform/pricing/)

Planning numbers for a small pilot are 20 seats, 32 MiB total documents per purchaser, and 8 MiB of paid documents per thread in addition to the current 32 MiB photo/reel limit. At full seat allocation that is 640 MiB of document payload before database overhead, trial data, and retained uploads. Renewals and replacement seats use remaining capacity after accounting for retained bytes. Validate these numbers against measured usage and exported HTML overhead before putting them on the storefront.

| Under load | Service behavior |
| --- | --- |
| New uploads approach the reserved storage or write budget | Pause new documents and retain drafts. Keep existing attachments downloadable while quota allows. |
| Push approaches its budget | Coalesce or defer eligible alerts within their delivery window. Drop stale work. Keep live thread updates available while quota allows. |
| Purchase cap reached | Close sales for the pilot. Existing entitlements retain their published limits. |
| Cloudflare returns a hard quota or transient failure | Show an accurate status with retry timing when known. Preserve drafts. Require a healthy smoke test before reopening optional features after an incident. |

Use independent kill switches for push delivery and new paid uploads. Test recovery and observe the service with both disabled. Keep redacted operational counters and a short owner runbook for storage pressure, delivery backlog, revoked entitlements, and rollback.

Measure how often threads approach the existing 2,000-mutation cap. Test that a full thread still opens, pages, and exports. Keep delete and attachment withdrawal available at the cap. Review raising the cap with measured headroom before advertising long-running hosted threads. If the cap stays, communicate it before the thread fills and let people start a continuation while preserving the original history.

## 8. Release acceptance and handoff

| Gate | Evidence required |
| --- | --- |
| Core conversation | Move a shared Wild West link from a real messaging app into iPhone Safari and Android Chrome. Exchange posts with the Windows and Android viewers, reconnect after an interruption, and verify a locked approval from a separate session. Confirm authorship, full paged history, deletion markers, and stable operation retries. |
| Performance and mobile UX | Record the time from server confirmation to display on two connected devices. Target under one second on a healthy connection, with at least 20 exchanges recorded. Verify keyboard and safe-area layout, text wrapping, large text, focus order, visible composer, long threads, low-power Android behavior, and no scroll jump while reading older posts. Record network and device conditions. |
| Native install and upgrade | Clean Windows install and upgrade, package launch, uninstall, and opening an existing file. On a physical Android phone, install the actual buyer APK from the download flow, launch from its icon, upgrade from a supported prior release, and verify editor state, file picker, sharing, and offline export. Document supported versions and any signing-key transition before distribution. |
| Portability | Open old HTML in both apps. Save a paged live thread with photos, reels, and deletion markers, reopen offline, reply, share the file, and reopen the precise shared copy on another device. Exercise locked export and camera denial/interruption on hardware. Include new attached documents when releasing paid uploads. |
| Isolation and recovery | Exercise unapproved locked access, cross-thread IDs, ownership forgery, unsafe attachment responses, stale permission, and failed writes. Rehearse deployment rollback with stored data and previously issued links. Preserve access controls and data through additive changes. Stage and production keys and test data stay separate. |
| Release bundle | Deliver a buyer-friendly Windows installer and directly installable Android APK, matching GPL source and build instructions, a short Start Here guide, release notes, checksums, and a versioned freeze. Verify archive contents, binaries, and corresponding source against the tested release. Record the tested Worker version and flags. |

Record each gate as passed, failed, or unverified, with build IDs, devices, commands or test steps, and dates. Emulators provide regression coverage. Physical install, camera, and background push each require real hardware evidence. A reproducible crash, lost draft or history, access bypass, duplicate charge, or wrong recipient is a release blocker for the affected path. The free release may proceed with an optional feature off when the user-facing copy and release notes match what ships. After rollout, smoke-test the homepage, current invites, and every advertised feature on the public endpoint. If a regression affects data or access, disable the affected feature and roll back to the tested compatible Worker version while preserving stored state.

Before charging for uploads, settle the price, seat count, retention and refund policy, purchase recovery, and supported file types against the pilot results. Before final visual polish, review the complete free and paid user journeys and record Luna's approval.
