/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
(() => {
    "use strict";
    const native = window.DysociateDevice;
    if (!native) return;
    const byId = id => document.getElementById(id);
    let editor, checkpointTimer, autosaveTimer, saving = false, imageBusy = false;
    let restorePending = true, resetting = false, pendingWrite;
    const database = new Promise((resolve, reject) => {
        const request = indexedDB.open("dysociate", 1);
        request.onupgradeneeded = () => request.result.createObjectStore("editor");
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });

    async function checkpoint(discard = false) {
        if (restorePending || (resetting && !discard)) return;
        clearTimeout(checkpointTimer);
        const db = await database;
        if (resetting && !discard) return;
        const transaction = db.transaction("editor", "readwrite");
        const complete = new Promise((resolve, reject) => {
            transaction.oncomplete = resolve;
            transaction.onabort = () => reject(transaction.error);
        });
        const store = transaction.objectStore("editor");
        const snapshot = editor.checkpoint();
        const documentToken = native.documentToken();
        if (discard || (!documentToken && !snapshot.changed && !snapshot.page.sections.length && !editor.hasDraft())) {
            store.delete("working");
        } else store.put({...snapshot, documentToken}, "working");
        return complete;
    }

    function preserveDraft() {
        clearTimeout(checkpointTimer);
        checkpointTimer = setTimeout(() => checkpoint().catch(() => {
            editor.message("Could not keep a recovery draft. Use Save HTML to keep your work.");
        }), 700);
    }

    function recoverLegacy(source, filename) {
        // Before editable metadata existed, generated posts used these
        // classes. Parse into an inert template and copy only plain data.
        // Imported nodes and arbitrary image URLs never enter the live DOM.
        const inert = document.createElement("template");
        inert.innerHTML = source;
        inert.content.querySelectorAll("script, style, template").forEach(node => node.remove());
        const selector = "article.post, article.comment, section.post, section.comment, section.text-section, section.hero, section.image-section";
        const sections = Array.from(inert.content.querySelectorAll(selector), section => {
            // Do not read a nested post into its parent's fields.
            section = section.cloneNode(true);
            section.querySelectorAll(selector).forEach(node => node.remove());
            const heading = section.querySelector("h1, h2");
            const picture = section.querySelector("img");
            const bodies = section.querySelector(".post-body")
                ? [section.querySelector(".post-body")] : Array.from(section.querySelectorAll("p"));
            const body = bodies.map(node => {
                node.querySelectorAll("br").forEach(br => br.replaceWith("\n"));
                return node.textContent.trim();
            }).filter(Boolean).join("\n\n");
            const src = picture?.getAttribute("src") || "";
            const embedded = /^data:image\/(?:png|jpe?g|gif|webp|bmp|x-ms-bmp|x-icon|vnd\.microsoft\.icon);base64,[A-Za-z0-9+/]+={0,2}$/i.test(src);
            return {kind:"Post", heading:heading?.textContent.trim() || "", body,
                image_data_url:embedded ? src : "", image_alt:picture?.getAttribute("alt") || ""};
        });
        if (!sections.length) throw Error("Choose an HTML thread created by dλsociate.");
        return {title:inert.content.querySelector("title")?.textContent.trim() || filename.replace(/\.html?$/i, ""), sections};
    }

    function previewThread() {
        const dialog = byId("mobile-preview-dialog");
        const content = byId("mobile-preview-content");
        const banner = byId("terminal-banner").cloneNode(true);
        banner.removeAttribute("id");
        const header = document.createElement("header");
        header.className = "thread-header";
        const heading = document.createElement("h1");
        heading.textContent = byId("thread-title").textContent;
        header.append(heading);
        // The editor has already escaped and rendered these posts and images.
        // Copy the reader view only, leaving the live composer and file alone.
        const thread = byId("thread").cloneNode(true);
        thread.removeAttribute("id");
        thread.querySelectorAll(".post-actions").forEach(node => node.remove());
        thread.querySelectorAll("[data-watch-reel]").forEach(node => node.remove());
        thread.querySelectorAll("a").forEach(link => link.removeAttribute("href"));
        content.replaceChildren(banner, header, thread, document.querySelector(".footer").cloneNode(true));
        byId("mobile-preview-draft").hidden = !editor.hasDraft();
        dialog.showModal();
        dialog.scrollTop = 0;
    }

    window.DysociateAndroid = {
        recoverLegacy,
        feedback(value) {
            const status = byId("mobile-feedback");
            status.textContent = value;
            status.hidden = !value;
        },
        async start(api) {
            editor = api;
            byId("mobile-open").onclick = () => native.showLaunch();
            byId("share-page").textContent = "Share";
            byId("mobile-photo").onclick = () => native.choose("image");
            byId("mobile-record").onclick = () => { if (!saving && !imageBusy) native.recordReel(); };
            byId("mobile-fresh").onclick = async () => {
                await editor.freshThread();
                byId("mobile-tools").open = false;
            };
            byId("mobile-copy").onclick = () => editor.saveOnAndroid("copy");
            byId("mobile-share").onclick = () => editor.saveOnAndroid("share");
            byId("mobile-text").onclick = () => native.chooseTextRecipient();
            byId("mobile-publish").onclick = () => native.choosePublish();
            byId("mobile-live").onclick = () => native.showLiveThreads();
            byId("mobile-live-open").onclick = () => native.openLiveLink();
            byId("mobile-offline-library").onclick = () => native.showOfflineThreads();
            byId("mobile-email-file").onclick = () => editor.prepareEmail(true);
            byId("mobile-preview").onclick = previewThread;
            byId("mobile-preview-close").onclick = () => byId("mobile-preview-dialog").close();
            byId("mobile-preview-dialog").addEventListener("close", () => {
                byId("mobile-preview-content").replaceChildren();
            });
            byId("mobile-help").onclick = () => native.showHelp();
            byId("mobile-terms").onclick = () => native.showTerms();
            document.addEventListener("visibilitychange", () => {
                if (document.hidden) checkpoint().catch(() => {});
            });
            try {
                const db = await database;
                const store = db.transaction("editor").objectStore("editor");
                const snapshot = await new Promise((resolve, reject) => {
                    const request = store.get("working");
                    request.onsuccess = () => resolve(request.result);
                    request.onerror = () => reject(request.error);
                });
                if (snapshot) {
                    editor.restore(snapshot);
                    if (native.restoreDocument(snapshot.documentToken || "")) {
                        editor.message("Restored your thread. Posts save to the same HTML file.");
                    } else if (snapshot.page.sections.length) {
                        editor.message("Recovered your thread. Use Save HTML to choose a save location.");
                    }
                }
            } catch (_) {
                editor.message("Could not restore the previous session. You can open an HTML file.");
            } finally {
                restorePending = false;
                native.ready();
            }
        },
        state(busy, loadingImage, draft, changed, filename) {
            saving = busy; imageBusy = loadingImage;
            byId("save-state").textContent = busy ? "Working…" : loadingImage ? "Preparing media…" :
                draft ? "Draft on this phone" : changed ? "Changes ready to save" :
                native.canAutoSave() ? filename : "Ready to post";
            ["mobile-fresh", "mobile-open", "mobile-photo", "mobile-copy", "mobile-share", "mobile-text", "mobile-publish", "mobile-email-file", "mobile-preview"].forEach(id => {
                byId(id).disabled = busy || loadingImage;
            });
            if (!restorePending) preserveDraft();
        },
        scheduleSave() {
            clearTimeout(autosaveTimer);
            if (native.canAutoSave()) autosaveTimer = setTimeout(() => editor.saveOnAndroid("auto"), 250);
        },
        async resetDocument() {
            if (restorePending) throw Error("Wait for the editor to finish opening.");
            if (!native.resetDocument()) throw Error("Wait for the current file operation, then try again.");
            clearTimeout(autosaveTimer);
            resetting = true;
            try { await checkpoint(true); }
            finally { resetting = false; }
        },
        cleanExport(root) {
            // The shared runtime goes with the thread. The Android controls,
            // CSS, and restricted WebView policy belong only to this app.
            root.querySelectorAll("[data-android-only]").forEach(node => node.remove());
            root.removeAttribute("data-android");
            root.querySelector("#share-page").textContent = "Share / Email ↗";
        },
        async write(mode, payload, name, type, {subject = "", body = "", recipient = ""} = {}) {
            if (pendingWrite) throw Error("Wait for the current file operation.");
            if (!native.beginWrite(mode, name, type, subject, body, recipient)) throw Error("Could not prepare the file.");
            const textStatus = ["text", "publish"].includes(mode) ? byId("share-status") : null;
            if (textStatus) textStatus.textContent = mode === "publish" ? "Publishing the HTML…" : "Preparing HTML attachment…";
            const result = new Promise((resolve, reject) => {
                pendingWrite = {resolve, reject, textStatus};
            });
            try {
                // Limit each bridge call. Keep UTF-16 surrogate pairs
                // together so emoji survive the streaming UTF-8 write.
                for (let start = 0; start < payload.length;) {
                    let end = Math.min(start + 256 * 1024, payload.length);
                    if (end < payload.length && /[\uD800-\uDBFF]/.test(payload[end - 1])) end--;
                    if (!native.appendWrite(payload.slice(start, end))) throw Error("Could not stage this file on the phone.");
                    start = end;
                    if (start < payload.length) await new Promise(done => setTimeout(done, 0));
                }
                native.finishWrite();
            } catch (error) {
                native.abortWrite();
                pendingWrite = null;
                if (textStatus) textStatus.textContent = error.message;
                throw error;
            }
            return result;
        },
        writeResult(saved, name, message, failed) {
            const request = pendingWrite;
            pendingWrite = null;
            if (!request) return;
            if (request.textStatus) request.textStatus.textContent = message;
            if (failed) request.reject(Error(message));
            else request.resolve({saved, name, message});
            // Run after the shared runtime applies the result and unlocks the
            // editor. The checkpoint records the new native save epoch too.
            setTimeout(() => checkpoint().catch(() => {}), 0);
        },
        async receive(kind, token, name, mime) {
            let accepted = false;
            try {
                if (saving || imageBusy) throw Error("Wait for the current file operation, then open the file again.");
                const result = await fetch("/incoming/" + token, {cache:"no-store"});
                if (!result.ok) throw Error("The selected file is unavailable.");
                const file = new File([await result.blob()], name, {type:mime});
                if (kind === "image") await editor.loadImage(file);
                else if (kind === "video") await editor.loadVideo(file);
                else accepted = await editor.openThread(file);
            } catch (error) {
                editor.message(error.message);
            } finally {
                native.receiveResult(token, !!accepted);
            }
        },
        closePreview() { byId("mobile-preview-dialog").close(); },
        closeReels() { byId("reel-dialog").close(); },
        closeRecorder() { byId("reel-recorder").close(); },
        launchInBrowser() { return editor.saveOnAndroid("browser"); },
        textRecipient(number) { return editor.saveOnAndroid("text", number); },
        textShareFailed(recipient, reason) {
            byId("share-status").textContent = reason;
            native.showTextShareError(recipient, reason);
        },
        emailThread() { return editor.prepareEmail(); },
        publishThread() { return editor.saveOnAndroid("publish"); },
        exitState() {
            if (byId("reel-recorder").open) return "record";
            if (byId("reel-dialog").open) return "reel";
            if (byId("mobile-preview-dialog").open) return "preview";
            return saving || imageBusy ? "busy" : editor && editor.dirty() ? "dirty" : "clean";
        },
        async exit(mode) {
            if (mode === "save" && !await editor.saveOnAndroid("save")) return;
            try { await checkpoint(mode === "discard"); } catch (_) {}
            native.exit();
        },
        pause() { checkpoint().catch(() => {}); },
        tell(message) { if (editor) editor.message(message); }
    };
})();
