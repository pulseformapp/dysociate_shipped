/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.function.Consumer;

final class NativeComposer extends ViewGroup {
    private static final int TEXT = 0xfffff1fa;
    private static final int INK = 0xff090512;
    private static final int ACCENT = 0xffff76cf;
    private static final int FIELD = 0xff190d23;
    private static final int DISABLED = 0xffd2adc8;
    // Order matches the Field enum in composer.h. Java owns the focusable
    // controls for selection, IME, TalkBack and keyboard navigation.
    private static final boolean AVAILABLE = load();
    private static native int[] geometry(int width, float scale, boolean result);
    private static native boolean render(Bitmap bitmap, float scale, boolean result);

    interface Submit { void create(String title, String body, Runnable ready, Consumer<String> failed); }
    interface Options { void open(String title, String body); }

    private int[] rectangles;
    private Bitmap backdrop;
    private final float scale;
    private final boolean result;

    private static boolean load() {
        try {
            System.loadLibrary("dysociate_composer");
            return true;
        } catch (UnsatisfiedLinkError unavailable) {
            return false;
        }
    }

    static boolean available() { return AVAILABLE; }

    static void show(Context context, String title, String body, String notice, Submit submit, Options options) {
        ScrollView scroll = new ScrollView(context);
        NativeComposer composer = new NativeComposer(context, false);
        scroll.addView(composer, new ScrollView.LayoutParams(-1, -2));
        AlertDialog dialog = new AlertDialog.Builder(context).setView(scroll).create();
        composer.populate(title, body, notice, dialog, submit, options);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.show();
    }

    static void showLink(Context context, String title, String url, Runnable open, Runnable share,
                         Runnable copy, Runnable manage) {
        ScrollView scroll = new ScrollView(context);
        NativeComposer composer = new NativeComposer(context, true);
        scroll.addView(composer, new ScrollView.LayoutParams(-1, -2));
        AlertDialog dialog = new AlertDialog.Builder(context).setView(scroll).create();
        TextView heading = composer.label("Thread ready");
        heading.setTextColor(ACCENT);
        heading.setTextSize(20);
        TextView name = composer.label(title);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView linkLabel = composer.label("Thread link");
        EditText link = composer.editor(url, false);
        link.setKeyListener(null);
        link.setShowSoftInputOnFocus(false);
        linkLabel.setLabelFor(link.getId());
        TextView status = composer.label("Anyone with the link can read and reply.");
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        Button options = composer.action("Manage thread", false, () -> {
            dialog.dismiss();
            manage.run();
        });
        Button done = composer.action("Done", false, dialog::dismiss);
        Button openLink = composer.action("Open link", true, open);
        Button copyLink = composer.action("Copy link", false, () -> {
            copy.run();
            status.setText("Link copied.");
        });
        Button shareLink = composer.action("Share link", false, share);
        composer.addFields(heading, name, null, linkLabel, link, status, options, done, openLink, copyLink, shareLink);
        dialog.show();
    }

    private NativeComposer(Context context, boolean result) {
        super(context);
        this.result = result;
        scale = Math.min(5, getResources().getDisplayMetrics().density
            * Math.max(1, getResources().getConfiguration().fontScale));
        setWillNotDraw(false);
        setFocusableInTouchMode(true);
        setDescendantFocusability(FOCUS_BEFORE_DESCENDANTS);
        setBackgroundColor(INK);
    }

    private void populate(String title, String body, String notice, AlertDialog dialog, Submit submit, Options options) {
        TextView heading = label("Create live thread");
        heading.setTextColor(ACCENT);
        heading.setTextSize(20);
        TextView titleLabel = label("Thread title");
        EditText titleInput = editor(title, false);
        titleLabel.setLabelFor(titleInput.getId());
        TextView bodyLabel = label("Opening post");
        EditText bodyInput = editor(body, true);
        bodyLabel.setLabelFor(bodyInput.getId());
        TextView status = label(notice);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        Button more = action("More options", false, () -> {
            String draftTitle = titleInput.getText().toString();
            String draftBody = bodyInput.getText().toString();
            dialog.dismiss();
            options.open(draftTitle, draftBody);
        });
        Button cancel = action("Cancel", false, dialog::dismiss);
        Button create = action("Create thread", true, null);
        create.setOnClickListener(view -> {
            setBusy(dialog, true, titleInput, bodyInput, more, cancel, create);
            status.setText("Creating live thread…");
            submit.create(titleInput.getText().toString(), bodyInput.getText().toString(), dialog::dismiss, error -> {
                status.setText(error);
                setBusy(dialog, false, titleInput, bodyInput, more, cancel, create);
            });
        });
        addFields(heading, titleLabel, titleInput, bodyLabel, bodyInput, status, more, cancel, create);
    }

    private void addFields(View... fields) {
        // Empty slots keep Java child indices aligned with the C++ Field enum.
        for (View field : fields) {
            View child = field == null ? new View(getContext()) : field;
            if (field == null) child.setVisibility(GONE);
            addView(child, new LayoutParams(-2, -2));
        }
    }

    private static void setBusy(AlertDialog dialog, boolean busy, View... fields) {
        dialog.setCancelable(!busy);
        for (View field : fields) field.setEnabled(!busy);
    }

    private TextView label(String title) {
        TextView label = new TextView(getContext());
        label.setText(title);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setTextColor(TEXT);
        label.setTypeface(Typeface.MONOSPACE);
        label.setTextSize(14);
        return label;
    }

    private EditText editor(String text, boolean multiline) {
        EditText input = new EditText(getContext());
        input.setId(View.generateViewId());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            | (multiline ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        input.setSingleLine(!multiline);
        input.setGravity((multiline ? Gravity.TOP : Gravity.CENTER_VERTICAL) | Gravity.START);
        input.setTextColor(TEXT);
        input.setBackgroundColor(FIELD);
        int pad = Math.round(8 * scale);
        input.setPadding(pad, pad, pad, pad);
        input.setText(text);
        if (multiline) {
            // Let multiline editing work with an outer ScrollView when the
            // keyboard opens or large fonts make the whole dialog scroll.
            input.setOnTouchListener((view, event) -> {
                getParent().requestDisallowInterceptTouchEvent(view.canScrollVertically(-1) || view.canScrollVertically(1));
                if (event.getActionMasked() == android.view.MotionEvent.ACTION_UP
                    || event.getActionMasked() == android.view.MotionEvent.ACTION_CANCEL) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            });
        }
        return input;
    }

    private Button action(String title, boolean primary, Runnable click) {
        Button button = new Button(getContext());
        button.setAllCaps(false);
        button.setText(title);
        button.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled}, new int[]{}},
            new int[]{primary ? INK : DISABLED, primary ? INK : TEXT}));
        button.setTextSize(14);
        button.setTypeface(Typeface.MONOSPACE);
        button.setPadding(0, 0, 0, 0);
        button.setBackground(new android.graphics.drawable.RippleDrawable(
            ColorStateList.valueOf(primary ? 0x4459234e : 0x66ff76cf),
            null, new android.graphics.drawable.ColorDrawable(-1)));
        if (click != null) button.setOnClickListener(view -> click.run());
        return button;
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        // Keep bitmap size bounded even on a large secondary display.
        width = Math.max(1, Math.min(4096, width));
        if (rectangles == null || width != getMeasuredWidth()) {
            rectangles = geometry(width, scale, result);
            backdrop = Bitmap.createBitmap(width, rectangles[0], Bitmap.Config.ARGB_8888);
            render(backdrop, scale, result);
        }
        for (int i = 0; i < getChildCount(); ++i) {
            int coordinate = 1 + 4 * i;
            getChildAt(i).measure(MeasureSpec.makeMeasureSpec(rectangles[coordinate + 2], MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(rectangles[coordinate + 3], MeasureSpec.EXACTLY));
        }
        setMeasuredDimension(width, rectangles[0]);
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        for (int i = 0; i < getChildCount(); ++i) {
            int coordinate = 1 + 4 * i;
            int x = rectangles[coordinate], y = rectangles[coordinate + 1];
            getChildAt(i).layout(x, y, x + rectangles[coordinate + 2], y + rectangles[coordinate + 3]);
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        if (backdrop != null) canvas.drawBitmap(backdrop, 0, 0, null);
    }
}
