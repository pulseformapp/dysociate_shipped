/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.Supplier;

final class LiveThreadDialog {
    // Keep requests serialized across Activity recreation. The pending draft,
    // credential and result are written before the UI is notified.
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private final EditorActivity activity;
    private final LiveClient client;

    LiveThreadDialog(EditorActivity activity) {
        this.activity = activity;
        client = new LiveClient(activity);
    }

    void promptOpen() {
        EditText field = new EditText(activity);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        field.setHint("Paste a dλsociate thread link");
        AlertDialog dialog = new AlertDialog.Builder(activity).setTitle("Open live link")
            .setView(field).setNegativeButton("Cancel", null).setPositiveButton("Open", null).create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String address = LiveClient.viewerUrl(activity, field.getText().toString());
            if (address == null) {
                field.setError("Paste a full dλsociate live thread link.");
                return;
            }
            dialog.dismiss();
            LiveThreadActivity.open(activity, address);
        });
    }

    void showCreate() {
        LiveClient.Draft draft = client.draft();
        String notice = (client.isLocal() ? "Local emulator test. " : client.isPilot() ? "HTTPS pilot. Use test content. " : "")
            + "Anyone with the link can read and reply.";
        String retryNotice = draft.locked || draft.attached
            ? "To retry, use the original access choices and attachment."
            : draft.body.isEmpty() ? "" : "Retry the saved draft to recover its link.";
        if (!NativeComposer.available() || draft.locked || draft.attached) {
            showOptions(draft.title, draft.body, notice, retryNotice, draft.locked);
            return;
        }
        String message = retryNotice.isEmpty() ? notice : notice + "\n" + retryNotice;
        NativeComposer.show(activity, draft.title, draft.body, message,
            (title, body, ready, failed) -> submitThread(title, body, null, false, "", thread -> {
                ready.run();
                NativeComposer.showLink(activity, thread.title, thread.url, () -> openLink(thread),
                    () -> shareLink(thread), () -> copyLink(thread), () -> showThread(thread));
            }, failed),
            (title, body) -> showOptions(title, body, notice, retryNotice, false));
    }

    private void showOptions(String initialTitle, String initialBody, String accessNotice, String retryNotice, boolean startLocked) {
        ScrollView scroll = new ScrollView(activity);
        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(20 * activity.getResources().getDisplayMetrics().density);
        form.setPadding(padding, padding / 2, padding, padding / 2);
        scroll.addView(form);
        TextView notice = new TextView(activity);
        notice.setText(accessNotice);
        form.addView(notice);
        EditText title = new EditText(activity);
        title.setSingleLine();
        title.setHint("Thread title");
        title.setText(initialTitle);
        form.addView(title);
        EditText body = new EditText(activity);
        body.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.setMinLines(3);
        body.setMaxLines(6);
        body.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        body.setHint("Opening post");
        body.setText(initialBody);
        form.addView(body);
        CheckBox locked = new CheckBox(activity);
        locked.setText("Locked · guests ask to join");
        EditText passkey = new EditText(activity);
        passkey.setSingleLine();
        passkey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passkey.setHint("Passkey (optional)");
        passkey.setVisibility(View.GONE);
        locked.setOnCheckedChangeListener((button, selected) -> {
            passkey.setVisibility(selected ? View.VISIBLE : View.GONE);
            notice.setText(selected ? "Approve requests in dλsociate." : accessNotice);
        });
        if (client.isPilot() || client.isLocal()) {
            form.addView(locked);
            form.addView(passkey);
            locked.setChecked(startLocked);
        }
        TextView status = new TextView(activity);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        status.setText(retryNotice);
        form.addView(status);
        LiveClient.Media[] media = {null};
        ImageView preview = new ImageView(activity);
        preview.setContentDescription("Photo preview");
        preview.setVisibility(View.GONE);
        form.addView(preview, new LinearLayout.LayoutParams(-1, padding * 4));
        Button photo = new Button(activity);
        photo.setText("Add photo");
        Button reel = new Button(activity);
        reel.setText("Record reel");
        Button remove = new Button(activity);
        remove.setText("Remove attachment");
        remove.setVisibility(View.GONE);
        if (client.isPilot() || client.isLocal()) {
            form.addView(photo);
            form.addView(reel);
            form.addView(remove);
        }

        AlertDialog dialog = new AlertDialog.Builder(activity).setTitle("Create live thread").setView(scroll)
            .setNegativeButton("Close", null).setNeutralButton("My threads", null).setPositiveButton("Create", null)
            .create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.show();
        photo.setOnClickListener(view -> {
            if (activity.chooseLivePhoto(uri -> {
                dialog.show();
                if (uri == null) return;
                setBusy(dialog, title, body, true, photo, reel, remove, locked, passkey);
                run(() -> readPhoto(uri), selected -> {
                    media[0] = selected;
                    preview.setImageBitmap(BitmapFactory.decodeByteArray(selected.bytes, 0, selected.bytes.length));
                    preview.setVisibility(View.VISIBLE);
                    remove.setVisibility(View.VISIBLE);
                    status.setText("Photo ready to post.");
                    setBusy(dialog, title, body, false, photo, reel, remove, locked, passkey);
                }, error -> {
                    status.setText(error);
                    setBusy(dialog, title, body, false, photo, reel, remove, locked, passkey);
                });
            })) dialog.hide();
        });
        reel.setOnClickListener(view -> {
            dialog.hide();
            activity.recordLiveReel(clip -> {
                dialog.show();
                if (clip == null) {
                    status.setText("No reel attached. Check camera and microphone access to try again.");
                    return;
                }
                media[0] = new LiveClient.Media("video/mp4", clip);
                preview.setImageDrawable(null);
                preview.setVisibility(View.GONE);
                remove.setVisibility(View.VISIBLE);
                status.setText("Reel ready to post.");
            });
        });
        remove.setOnClickListener(view -> {
            media[0] = null;
            preview.setImageDrawable(null);
            preview.setVisibility(View.GONE);
            remove.setVisibility(View.GONE);
            status.setText("");
        });
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(view -> showHistory());
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String requestedTitle = title.getText().toString();
            String opening = body.getText().toString();
            boolean requiresApproval = locked.isChecked();
            String code = passkey.getText().toString();
            LiveClient.Media selected = media[0];
            setBusy(dialog, title, body, true, photo, reel, remove, locked, passkey);
            status.setText("Creating live thread…");
            submitThread(requestedTitle, opening, selected, requiresApproval, code, thread -> {
                dialog.dismiss();
                showThread(thread);
            }, error -> {
                status.setText(error);
                setBusy(dialog, title, body, false, photo, reel, remove, locked, passkey);
            });
        });
    }

    private void submitThread(String title, String body, LiveClient.Media media, boolean locked,
                              String passkey, Consumer<LiveClient.ThreadLink> completed, Consumer<String> failed) {
        run(() -> client.create(title, body, media, locked, passkey), completed, failed);
    }

    private LiveClient.Media readPhoto(Uri uri) {
        try {
            BitmapFactory.Options size = new BitmapFactory.Options();
            size.inJustDecodeBounds = true;
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(input, null, size);
            }
            if (!"image/jpeg".equals(size.outMimeType) && !"image/png".equals(size.outMimeType)) {
                throw new IllegalArgumentException("Choose a JPEG or PNG photo.");
            }
            if (size.outWidth < 1 || size.outHeight < 1 || (long) size.outWidth * size.outHeight > 40_000_000) {
                throw new IllegalArgumentException("Choose a photo up to 40 megapixels.");
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            while (Math.max(size.outWidth, size.outHeight) / options.inSampleSize > 1600) options.inSampleSize *= 2;
            Bitmap bitmap;
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                bitmap = BitmapFactory.decodeStream(input, null, options);
            }
            if (bitmap == null) throw new IllegalArgumentException("This photo could not be read.");
            try (ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, output) || output.size() > 1024 * 1024) {
                    throw new IllegalArgumentException("Choose a smaller photo.");
                }
                return new LiveClient.Media("image/jpeg", output.toByteArray());
            } finally {
                bitmap.recycle();
            }
        } catch (IOException | SecurityException error) {
            throw new IllegalArgumentException("This photo could not be opened.");
        }
    }

    private void setBusy(AlertDialog dialog, EditText title, EditText body, boolean busy, View... controls) {
        dialog.setCancelable(!busy);
        for (int button : new int[]{AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL}) {
            dialog.getButton(button).setEnabled(!busy);
        }
        title.setEnabled(!busy);
        body.setEnabled(!busy);
        for (View control : controls) control.setEnabled(!busy);
    }

    private void showHistory() {
        List<LiveClient.ThreadLink> threads = client.threads();
        AlertDialog.Builder builder = new AlertDialog.Builder(activity).setTitle("My live threads")
            .setNegativeButton("Back", null);
        if (threads.isEmpty()) builder.setMessage("Threads you create on this phone will appear here.");
        else {
            String[] labels = new String[threads.size()];
            for (int index = 0; index < threads.size(); index++) {
                LiveClient.ThreadLink thread = threads.get(index);
                labels[index] = (index + 1) + ". " + thread.title + (thread.locked() ? " · Locked" : "") +
                    (thread.deleted ? " (opening post deleted)" : "");
            }
            builder.setItems(labels, (dialog, index) -> showThread(threads.get(index)));
        }
        builder.show();
    }

    private void showThread(LiveClient.ThreadLink thread) {
        String open = thread.locked() ? "Manage requests" : "Open link";
        String[] actions = thread.deleted ? new String[]{open, "Share link", "Copy link"}
            : new String[]{open, "Share link", "Copy link", "Delete opening post"};
        new AlertDialog.Builder(activity).setTitle(thread.title).setItems(actions, (dialog, index) -> {
            switch (index) {
                case 0:
                    if (thread.locked()) loadRequests(thread, null, false);
                    else openLink(thread);
                    break;
                case 1:
                    shareLink(thread);
                    break;
                case 2:
                    copyLink(thread);
                    if (android.os.Build.VERSION.SDK_INT < 33) tell("Link copied.");
                    break;
                case 3: confirmDelete(thread); break;
                default: break;
            }
        }).setNegativeButton("Done", null).show();
    }

    private void openLink(LiveClient.ThreadLink thread) {
        LiveThreadActivity.open(activity, thread.url);
    }

    private void shareLink(LiveClient.ThreadLink thread) {
        Intent share = new Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, thread.url);
        launch(Intent.createChooser(share, "Share live thread"));
    }

    private void copyLink(LiveClient.ThreadLink thread) {
        ClipboardManager clipboard = activity.getSystemService(ClipboardManager.class);
        clipboard.setPrimaryClip(ClipData.newPlainText("dλsociate live thread", thread.url));
    }

    private void loadRequests(LiveClient.ThreadLink thread, LiveClient.JoinRequest selected, boolean approve) {
        AlertDialog progress = new AlertDialog.Builder(activity)
            .setMessage(selected == null ? "Loading join requests…" : "Saving decision…").setCancelable(false).show();
        run(() -> client.joinRequests(thread, selected, approve), requests -> {
            progress.dismiss();
            if (selected != null) tell(approve ? "Guest approved. Their waiting page will open shortly." : "Request declined.");
            showRequests(thread, requests);
        }, error -> {
            progress.dismiss();
            new AlertDialog.Builder(activity).setTitle("Could not load join requests").setMessage(error)
                .setPositiveButton("OK", (dialog, button) -> loadRequests(thread, null, false))
                .setNegativeButton("Back", (dialog, button) -> showThread(thread)).show();
        });
    }

    private void showRequests(LiveClient.ThreadLink thread, List<LiveClient.JoinRequest> requests) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity).setTitle("Join requests")
            .setNegativeButton("Back", (dialog, button) -> showThread(thread))
            .setPositiveButton("Refresh", (dialog, button) -> loadRequests(thread, null, false))
            .setNeutralButton("Creator view", (dialog, button) -> openCreator(thread));
        if (requests.isEmpty()) builder.setMessage("No pending requests. Use Refresh after a guest requests to join.");
        else {
            String[] labels = new String[requests.size()];
            for (int index = 0; index < requests.size(); index++) {
                LiveClient.JoinRequest request = requests.get(index);
                labels[index] = request.name + "\n" + request.time;
            }
            builder.setItems(labels, (dialog, index) -> {
                LiveClient.JoinRequest selected = requests.get(index);
                new AlertDialog.Builder(activity).setTitle(selected.name)
                    .setPositiveButton("Approve", (choice, button) -> loadRequests(thread, selected, true))
                    .setNegativeButton("Decline", (choice, button) -> loadRequests(thread, selected, false))
                    .setNeutralButton("Cancel", (choice, button) -> showRequests(thread, requests)).show();
            });
        }
        builder.show();
    }

    private void openCreator(LiveClient.ThreadLink thread) {
        AlertDialog progress = new AlertDialog.Builder(activity).setMessage("Opening creator view…").setCancelable(false).show();
        run(() -> client.creatorLink(thread), link -> {
            progress.dismiss();
            launch(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
        }, error -> {
            progress.dismiss();
            new AlertDialog.Builder(activity).setTitle("Could not open creator view").setMessage(error)
                .setPositiveButton("OK", (dialog, button) -> showThread(thread)).show();
        });
    }
    private void confirmDelete(LiveClient.ThreadLink thread) {
        new AlertDialog.Builder(activity).setTitle("Delete opening post")
            .setMessage("Delete your opening post? Replies and the link will stay available.")
            .setNegativeButton("Cancel", (dialog, button) -> showThread(thread))
            .setPositiveButton("Delete", (dialog, button) -> {
                AlertDialog progress = new AlertDialog.Builder(activity).setMessage("Deleting opening post…")
                    .setCancelable(false).show();
                run(() -> { client.deleteOpeningPost(thread); return null; }, ignored -> {
                    progress.dismiss();
                    tell("Opening post deleted. The link still works.");
                }, error -> {
                    progress.dismiss();
                    new AlertDialog.Builder(activity).setTitle("Could not delete the opening post")
                        .setMessage(error).setPositiveButton("OK", (notice, action) -> showThread(thread)).show();
                });
            }).show();
    }

    private void launch(Intent intent) {
        try { activity.startActivity(intent); }
        catch (ActivityNotFoundException error) { tell("No app can open that link. Use Copy link instead."); }
    }

    private void tell(String message) {
        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
    }

    private <T> void run(Supplier<T> work, Consumer<T> success, Consumer<String> failure) {
        IO.execute(() -> {
            try {
                T result = work.get();
                onActivity(() -> success.accept(result));
            } catch (IllegalArgumentException error) {
                onActivity(() -> failure.accept(error.getMessage()));
            }
        });
    }

    private void onActivity(Runnable update) {
        activity.runOnUiThread(() -> {
            if (!activity.isFinishing() && !activity.isDestroyed()) update.run();
        });
    }
}
