/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
package com.lunasoft.dysociate;

import android.app.Dialog;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.function.Consumer;

// Capture and review use one dialog. The camera is released before playback
// opens its decoder. Every exit path discards the temporary cache file.
@SuppressWarnings("deprecation")
final class ReelRecorder {
    static final int MAX_BYTES = 4 * 1024 * 1024;
    private static final int MAX_MS = 29_500;
    private final EditorActivity activity;
    private final Consumer<byte[]> complete;
    private final Dialog dialog;
    private final FrameLayout media;
    private final TextView status;
    private final Button record, stop, use, retake;
    private final Handler clock = new Handler(Looper.getMainLooper());
    private Camera camera;
    private MediaRecorder encoder;
    private SurfaceHolder surface;
    private VideoView review;
    private File file;
    private byte[] accepted;
    private long started;

    ReelRecorder(EditorActivity activity, Consumer<byte[]> complete) {
        this.activity = activity;
        this.complete = complete;
        dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout column = new LinearLayout(activity);
        column.setOrientation(LinearLayout.VERTICAL);
        int inset = Math.round(16 * activity.getResources().getDisplayMetrics().density);
        column.setPadding(inset, inset, inset, inset);
        column.setBackgroundColor(0xff090512);
        media = new FrameLayout(activity);
        column.addView(media, new LinearLayout.LayoutParams(-1, 0, 1));
        status = new TextView(activity);
        status.setTextColor(0xffff76cf);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        column.addView(status);
        LinearLayout controls = new LinearLayout(activity);
        controls.setGravity(Gravity.CENTER);
        column.addView(controls);
        record = button(controls, "Record", this::start);
        stop = button(controls, "Stop", this::stop);
        retake = button(controls, "Retake", this::prepare);
        use = button(controls, "Use clip", this::accept);
        button(controls, "Cancel", this::dismiss);
        dialog.setContentView(column);
        dialog.setOnDismissListener(ignored -> {
            clearCapture();
            if (review != null) review.stopPlayback();
            discardFile();
            complete.accept(accepted);
        });
        dialog.show();
        dialog.getWindow().setLayout(-1, -1);
        prepare();
    }

    private Button button(LinearLayout row, String title, Runnable action) {
        Button button = new Button(activity);
        button.setText(title);
        button.setOnClickListener(view -> action.run());
        row.addView(button);
        return button;
    }

    private void stage(String message, boolean canRecord, boolean recording, boolean hasClip, boolean canRetake) {
        status.setText(message);
        record.setVisibility(canRecord ? View.VISIBLE : View.GONE);
        stop.setVisibility(recording ? View.VISIBLE : View.GONE);
        use.setVisibility(hasClip ? View.VISIBLE : View.GONE);
        retake.setVisibility(canRetake ? View.VISIBLE : View.GONE);
    }

    private void prepare() {
        if (review != null) { review.stopPlayback(); review = null; }
        discardFile();
        stage("Opening camera…", false, false, false, false);
        media.removeAllViews();
        SurfaceView preview = new SurfaceView(activity);
        preview.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override public void surfaceCreated(SurfaceHolder holder) {
                surface = holder;
                try {
                    camera = Camera.open(0);
                    camera.setDisplayOrientation(orientation());
                    camera.setPreviewDisplay(holder);
                    camera.startPreview();
                    stage("Ready to record up to 30 seconds.", true, false, false, false);
                } catch (IOException | RuntimeException error) {
                    clearCapture();
                    stage("Could not open the camera.", false, false, false, true);
                }
            }
            @Override public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}
            @Override public void surfaceDestroyed(SurfaceHolder holder) { clearCapture(); }
        });
        media.addView(preview, new FrameLayout.LayoutParams(-1, -1));
    }

    private int orientation() {
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(0, info);
        int rotation = activity.getWindowManager().getDefaultDisplay().getRotation() * 90;
        return (info.orientation - rotation + 360) % 360;
    }

    private void start() {
        if (camera == null || encoder != null) return;
        try {
            file = File.createTempFile("dysociate-reel-", ".mp4", activity.getCacheDir());
            camera.unlock();
            encoder = new MediaRecorder();
            encoder.setCamera(camera);
            encoder.setAudioSource(MediaRecorder.AudioSource.MIC);
            encoder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
            int quality = CamcorderProfile.hasProfile(0, CamcorderProfile.QUALITY_480P)
                ? CamcorderProfile.QUALITY_480P : CamcorderProfile.QUALITY_LOW;
            CamcorderProfile profile = CamcorderProfile.get(0, quality);
            encoder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            encoder.setVideoSize(profile.videoFrameWidth, profile.videoFrameHeight);
            encoder.setVideoFrameRate(profile.videoFrameRate);
            encoder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            encoder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            encoder.setAudioChannels(1);
            encoder.setAudioSamplingRate(44_100);
            encoder.setVideoEncodingBitRate(720_000);
            encoder.setAudioEncodingBitRate(64_000);
            encoder.setOrientationHint(orientation());
            encoder.setMaxDuration(MAX_MS);
            encoder.setMaxFileSize(MAX_BYTES - 32_768);
            encoder.setOutputFile(file.getAbsolutePath());
            encoder.setPreviewDisplay(surface.getSurface());
            encoder.setOnInfoListener((instance, event, extra) -> {
                if (encoder == instance && (event == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED
                    || event == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED)) stop();
            });
            encoder.setOnErrorListener((instance, event, extra) -> {
                if (encoder == instance) recordingFailed();
            });
            encoder.prepare();
            encoder.start();
            started = SystemClock.elapsedRealtime();
            stage("Recording · 30 seconds left", false, true, false, false);
            clock.postDelayed(tick, 200);
        } catch (IOException | RuntimeException error) {
            Log.w("DysociateReel", "Could not start camera encoding", error);
            recordingFailed();
        }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (encoder == null) return;
            long remaining = MAX_MS - (SystemClock.elapsedRealtime() - started);
            if (remaining <= 0) stop();
            else {
                status.setText("Recording · " + ((remaining + 999) / 1000) + " seconds left");
                clock.postDelayed(this, 200);
            }
        }
    };

    private void stop() {
        if (encoder == null) return;
        try { encoder.stop(); }
        catch (RuntimeException error) { recordingFailed(); return; }
        clearCapture();
        if (file == null || file.length() == 0 || file.length() > MAX_BYTES) {
            recordingFailed();
            return;
        }
        media.removeAllViews();
        review = new VideoView(activity);
        media.addView(review, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        MediaController playback = new MediaController(activity);
        review.setMediaController(playback);
        review.setOnPreparedListener(player -> {
            review.seekTo(1);
            stage("Preview your reel.", false, false, true, true);
        });
        review.setOnErrorListener((player, what, extra) -> {
            recordingFailed();
            return true;
        });
        stage("Preparing preview…", false, false, false, true);
        review.setVideoPath(file.getAbsolutePath());
    }

    private void accept() {
        try {
            if (file == null || file.length() < 8 || file.length() > MAX_BYTES) throw new IOException();
            accepted = Files.readAllBytes(file.toPath());
            dismiss();
        } catch (IOException error) { recordingFailed(); }
    }

    private void recordingFailed() {
        clearCapture();
        if (review != null) { review.stopPlayback(); review = null; }
        media.removeAllViews();
        discardFile();
        stage("Could not finish the reel. Retake to try again.", false, false, false, true);
    }

    private void clearCapture() {
        clock.removeCallbacks(tick);
        if (encoder != null) { encoder.release(); encoder = null; }
        if (camera != null) { camera.release(); camera = null; }
    }

    private void discardFile() {
        if (file != null) { file.delete(); file = null; }
    }

    void dismiss() { dialog.dismiss(); }
}
