# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SdkRoot,
    [Parameter(Mandatory)][string]$JavaHome,
    [string]$Python = 'python',
    [string]$Platform = 'android-36',
    [string]$BuildTools = '36.0.0',
    [string]$Shared = (Join-Path $PSScriptRoot '..\python_pagebuilder'),
    [string]$Output = (Join-Path $PSScriptRoot 'dist'),
    [string]$BuildDirectory = (Join-Path $PSScriptRoot 'build'),
    [string]$Keystore,
    [string]$KeyAlias,
    [string]$KeystorePasswordEnvironment,
    [switch]$DebugWebView,
    [switch]$LiveLoopback,
    [switch]$LivePilot,
    [string]$NativeNdk
)
$ErrorActionPreference = 'Stop'
if (($LiveLoopback -or $LivePilot) -and -not $DebugWebView) { throw 'Live test modes require -DebugWebView.' }
if ($LiveLoopback -and $LivePilot) { throw 'Choose one live test mode.' }

function Invoke-BuildTool {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Executable exited with code $LASTEXITCODE." }
}

$sdkPath = (Resolve-Path -LiteralPath $SdkRoot).Path
$jdkPath = (Resolve-Path -LiteralPath $JavaHome).Path
$sharedPath = (Resolve-Path -LiteralPath $Shared).Path
$toolsPath = if ([IO.Path]::IsPathRooted($BuildTools)) { $BuildTools } else { Join-Path $sdkPath "build-tools/$BuildTools" }
$platformJar = Join-Path $sdkPath "platforms/$Platform/android.jar"
$manifest = Join-Path $PSScriptRoot 'app/AndroidManifest.xml'
[xml]$manifestData = Get-Content -LiteralPath $manifest -Raw
$version = $manifestData.manifest.GetAttribute('versionName', 'http://schemas.android.com/apk/res/android')
$outPath = (New-Item -ItemType Directory -Path $Output -Force).FullName
$buildPath = (New-Item -ItemType Directory -Path $BuildDirectory -Force).FullName
$stage = Join-Path $buildPath ([Guid]::NewGuid().ToString('N'))
$classes = Join-Path $stage 'classes'
$dex = Join-Path $stage 'dex'
$null = New-Item -ItemType Directory -Path $classes,$dex
$apk = Join-Path $stage 'unsigned.apk'
$aligned = Join-Path $stage 'aligned.apk'
$resources = Join-Path $stage 'resources.zip'
$jar = Join-Path $stage 'classes.jar'

$oldJava = $env:JAVA_HOME
try {
    # aapt2 assigns the icon resource ID. Java does not refer to generated R
    # classes, so it can compile directly against the Android platform stubs.
    $env:JAVA_HOME = $jdkPath
    Invoke-BuildTool $Python @((Join-Path $PSScriptRoot 'build_assets.py'), '--shared', $sharedPath, '--stage', $stage)
    if ($LivePilot) {
        '1' | Set-Content -LiteralPath (Join-Path $stage 'assets/live-pilot') -Encoding ascii
    }
    if ($LiveLoopback) {
        # The production manifest and APK never pick up the emulator marker
        # or this loopback-only network exception.
        '1' | Set-Content -LiteralPath (Join-Path $stage 'assets/live-loopback') -Encoding ascii
        $xmlDir = New-Item -ItemType Directory -Path (Join-Path $stage 'res/xml')
        @'
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
        <domain>127.0.0.1</domain>
    </domain-config>
</network-security-config>
'@ | Set-Content -LiteralPath (Join-Path $xmlDir.FullName 'live_test.xml') -Encoding utf8
        $android = 'http://schemas.android.com/apk/res/android'
        $null = $manifestData.manifest.application.SetAttribute('networkSecurityConfig', $android, '@xml/live_test')
        $manifest = Join-Path $stage 'AndroidManifest.xml'
        $manifestData.Save($manifest)
    }
    $aapt = Join-Path $toolsPath 'aapt2.exe'
    Invoke-BuildTool $aapt @('compile', '--dir', (Join-Path $stage 'res'), '-o', $resources)
    $link = @('link', '-o', $apk, '-I', $platformJar, '--manifest', $manifest, '-A', (Join-Path $stage 'assets'))
    if ($DebugWebView) { $link += '--debug-mode' }
    Invoke-BuildTool $aapt ($link + @($resources))
    $sources = @(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'app/src') -File -Recurse -Filter '*.java' |
        ForEach-Object FullName)
    Invoke-BuildTool (Join-Path $jdkPath 'bin/javac.exe') (@('--release', '8', '-encoding', 'UTF-8', '-classpath', $platformJar, '-d', $classes) + $sources)
    [IO.Compression.ZipFile]::CreateFromDirectory($classes, $jar)
    Invoke-BuildTool (Join-Path $toolsPath 'd8.bat') @('--lib', $platformJar, '--min-api', '26', '--output', $dex, $jar)
    $archive = [IO.Compression.ZipFile]::Open($apk, [IO.Compression.ZipArchiveMode]::Update)
    try {
        $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, (Join-Path $dex 'classes.dex'), 'classes.dex')
        if ($NativeNdk) {
            $toolchain = Join-Path (Resolve-Path -LiteralPath $NativeNdk).Path 'build/cmake/android.toolchain.cmake'
            $nativeSource = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../dysociate_native')).Path
            $cmake = (Get-Command cmake).Source
            $ninja = (Get-Command ninja).Source
            foreach ($abi in 'arm64-v8a','armeabi-v7a','x86_64') {
                $nativeBuild = Join-Path $stage "native/$abi"
                Invoke-BuildTool $cmake @('-S', $nativeSource, '-B', $nativeBuild, '-G', 'Ninja',
                    "-DCMAKE_MAKE_PROGRAM=$ninja", "-DCMAKE_TOOLCHAIN_FILE=$toolchain", "-DANDROID_ABI=$abi",
                    '-DANDROID_PLATFORM=android-26', '-DANDROID_STL=c++_static', '-DCMAKE_BUILD_TYPE=Release')
                Invoke-BuildTool $cmake @('--build', $nativeBuild)
                $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,
                    (Join-Path $nativeBuild 'libdysociate_composer.so'), "lib/$abi/libdysociate_composer.so",
                    [IO.Compression.CompressionLevel]::NoCompression)
            }
        }
    } finally {
        $archive.Dispose()
    }
    Invoke-BuildTool (Join-Path $toolsPath 'zipalign.exe') @('-f', '-P', '16', '4', $apk, $aligned)

    # A persistent local key lets successive local builds install as updates.
    # Supply an independent private release key for public distribution.
    $localSigning = -not $Keystore
    if ($localSigning) {
        $Keystore = Join-Path $buildPath 'local-test.keystore'
        $KeyAlias = 'dysociate-local'
        if (-not (Test-Path -LiteralPath $Keystore)) {
            Invoke-BuildTool (Join-Path $jdkPath 'bin/keytool.exe') @(
                '-genkeypair', '-keystore', $Keystore, '-alias', $KeyAlias, '-storepass', 'android',
                '-keypass', 'android', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
                '-dname', 'CN=dysociate local test, O=LunaSoft, C=US')
        }
    }
    $name = if ($LivePilot) { "dysociate-$version-pilot-qa.apk" }
        elseif ($DebugWebView) { "dysociate-$version-qa.apk" } else { "dysociate-$version.apk" }
    if ($NativeNdk) { $name = $name.Replace('.apk', '-native-preview.apk') }
    $destination = Join-Path $outPath $name
    $sign = @('sign', '--v4-signing-enabled', 'false', '--ks', (Resolve-Path -LiteralPath $Keystore).Path, '--out', $destination)
    if ($KeyAlias) { $sign += @('--ks-key-alias', $KeyAlias) }
    if ($localSigning) { $sign += @('--ks-pass', 'pass:android', '--key-pass', 'pass:android') }
    elseif ($KeystorePasswordEnvironment) { $sign += @('--ks-pass', "env:$KeystorePasswordEnvironment") }
    $signer = Join-Path $toolsPath 'apksigner.bat'
    Invoke-BuildTool $signer ($sign + @($aligned))
    Invoke-BuildTool $signer @('verify', '--verbose', $destination)
    Write-Output $destination
} finally {
    $env:JAVA_HOME = $oldJava
}
