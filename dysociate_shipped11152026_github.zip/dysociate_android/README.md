# dλsociate for Android

created by luna love, lunasoft λ 2026

A thread editor for Android 8.0 and later. Each exported HTML file contains its posts, replies, pictures, and browser editor. The desktop and Android apps can take turns editing the same portable file.

Tap **Create live thread** for a title and an opening text post.
After creation, tap **Open link** to chat in the app or **Share link** to
send the URL through Android's share sheet. Tap **Open live link** and paste
an invite someone sent you. The live view also has **Open in browser**.
**My threads** lists the live
threads you created on this installation. You can delete their opening
posts while keeping their links and replies available.

Tap **Record reel** in the composer, grant camera and microphone access, then
record for up to 30 seconds. Preview it and choose **Use clip** or **Retake**.
Post it, then tap **Reels** to watch the thread's clips. The video travels
inside the saved HTML. Earlier exported HTML files can still play their reels.
The pilot adds **Add photo** and **Record reel** to **Create live thread**.
**Fresh Thread** clears the editor, its save location,
and recovery draft. Save first to keep the current thread. Existing saved
files stay where they are. **More** opens Preview, Save a copy, Help, and Terms.

## On your phone

1. Open the APK from Downloads and follow Android’s installation prompt. Open **dλsociate**. Read the license and Karmic Law screens and scroll to the bottom of each agreement.
2. Tap **New post** and add text, a picture, or both. Tap **Post to thread**. **Thread details** lets you set the title, header text, and optional HTTPS browser editor address.
3. Tap **Save HTML** and choose a folder in Android’s save picker. The default filename is `index.html`. Changes to posts save back to the selected document while it is open and writable.
4. To continue a conversation, download its HTML attachment and choose **Launch → Open HTML in dλsociate**. Use **Reply** under a post. **Save a copy** exports the current thread to a different location, including when a provider makes the original read-only.
5. Tap **Preview** to see the posted thread and its pictures. **Back to editor** keeps your unfinished draft.
6. **Share / Email → Email · HTML attached** opens a compatible mail app with the subject, message, and HTML attachment filled in. Add a recipient and send from your mail app. **Email draft (.eml)** prepares a portable message file with the HTML inside. **Share HTML file** attaches the thread in Android’s general share sheet.
7. **Launch → Open HTML in browser** opens a copy of the current posted thread in a compatible browser. Save edits made in the browser as a separate HTML copy.
8. **Share / Email → Text HTML attachment** lets you pick a contact’s phone number or enter one manually. The default texting app receives the number and HTML if it accepts that combination. Check both in the draft before you send. If the handoff fails, a dialog explains why and offers **Email HTML** or **Text only** to open the addressed conversation.
9. **Share / Email → Publish & text link** uploads an HTML copy to `threads.dysociate.org` when publishing is enabled. Enter your publisher key, then choose **Text link** to open an addressed text draft with the URL filled in. **Copy link** works with other messaging apps. Anyone with the link can open that copy and save their own edits.

The recipient can open the file in either app or a full browser. If their mail app shows a read-only preview, they can download the attachment first. Separate copies stay independent. Share the newest copy to continue the conversation.

The app recovers its working draft after a restart and reconnects to the same save location when Android grants lasting access. If the provider makes the file read-only, access is revoked, or the recovered draft belongs to an earlier saved version, **Save HTML** asks you to choose a location. Photo access and document access are limited to what you select. Help and terms are available in the toolbar.

## Build on Windows

Install JDK 17, the Android SDK Platform 36 and Build-Tools 36.0.0, and Python 3.11 or newer with Tcl/Tk and Pillow. A standard Windows Python installation includes Tcl/Tk. The build script uses the SDK tools directly and does not need Gradle.

```powershell
python -m pip install Pillow
.\dysociate_android\build.ps1 -SdkRoot 'C:\Android\Sdk' -JavaHome 'C:\Java\jdk-17'
```

The source archive has `dysociate_android` and `python_pagebuilder` as sibling folders. The APK appears under `dysociate_android/dist`. Pass `-Keystore` and `-KeyAlias` to sign with your own release key. The default build uses a persistent local test key under `build`. Keep signing keys separate from the source archive.

## How it fits together

- `build_assets.py` stages the Android entry page from the desktop renderer and its shared JavaScript runtime. It adds the mobile controls and policy only to the packaged entry page.
- `EditorActivity.java` owns the native agreements, document picker, private staging, and share sheet. It hands the email composer a read-only URI for just the exported HTML attachment. The WebView serves bundled assets and the selected byte stream from a local virtual origin. Native network access is used by `PublisherClient.java` when the user publishes or removes a hosted copy. The APK requests no broad storage permission.
- Text sharing reads only the phone number returned by Android’s contact picker. The number is used for the compose handoff and stays out of exported HTML and recovery drafts.
- `mobile.js` adapts the editor to Android, checkpoints work in local IndexedDB, and streams UTF-8 exports over the bridge. Imported HTML is treated as data. Legacy generated sections can recover text and embedded raster images. Custom layouts and external image URLs are outside that recovery format.
- A write back to a selected file checks its current bytes against the last known version before replacing it. **Save a copy** is available if another app changed the original. Android storage providers differ in whether they allow a file to be edited.
- Each successful save creates a new identity token. The local recovery snapshot carries that token, and the private native record carries its URI and fingerprint. A recovery can reconnect only when those tokens match and Android still grants access. An older snapshot therefore cannot silently overwrite a newer saved thread after a process interruption.
- Back navigation uses the Android 13+ platform callback, including on Android 16, and the legacy callback on earlier versions. An unfinished draft opens the save/quit prompt.
- The exported HTML removes the Android-only assets and controls. It carries the common browser runtime, images, and license in one file.

GPL-3.0-or-later. See `python_pagebuilder/LICENSE` for the full license and project terms.

## Verify on an emulator

Use a dedicated Android emulator with a 1080×1920 display at 420 dpi and Node.js 22 or newer. Build with `-DebugWebView` and install that QA APK on the emulator. The integration script accepts only emulator serials and writes synthetic files to Downloads. It exercises the real Android pickers and share sheet.

```powershell
python .\dysociate_android\tests\create_fixtures.py .\android-test-files
$adb = 'C:\Android\Sdk\platform-tools\adb.exe'
& $adb -s emulator-5554 push .\android-test-files\Dysociate-Android-QA.html /sdcard/Download/
& $adb -s emulator-5554 push .\android-test-files\Photo-QA.png /sdcard/Download/
node .\dysociate_android\test_android.mjs $adb emulator-5554 .\android-test-files
```

The tests cover desktop HTML import, photo replies, preview and draft preservation, HTML and `.eml` sharing, canceled saves, the Back prompt, recovery after a process restart, refusal to bind an older checkpoint to a newer file, and preserving changes made by another editor. Run them on Android 16 to exercise the API 36 Back behavior.
