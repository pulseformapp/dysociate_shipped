# dλsociate link publishing

An optional Cloudflare service for the Windows and Android apps. The app uploads an HTML snapshot only when you choose **Publish link**. The service returns an address on `threads.dysociate.org` that anyone with the link can open. Recipients can use the embedded browser editor and save a new HTML copy. Sharing the URL gives everyone the same snapshot. Replies saved by recipients belong to their own copies.

Windows offers **Share → Publish link → Copy link**. Android offers **Share / Email → Publish & text link** and opens the default texting app with the recipient and URL filled in. Choose **Send** in your texting app when you’re ready. A publisher key authorizes uploads and removals. Enter it in either app when prompted. The apps keep the key in memory for the current session.

## Deploy on Cloudflare

1. In the Cloudflare account that manages `dysociate.org`, enable R2 if it is inactive. Cloudflare requires an R2 subscription checkout, including to use its free allowance. Use Workers Free and R2 Standard. This Worker uses a dedicated private bucket. [Cloudflare R2 setup](https://developers.cloudflare.com/r2/get-started/)
2. Open PowerShell in this folder and run the commands below. Choose the account that owns the `dysociate.org` zone. The Worker configuration binds `threads.dysociate.org` as its custom domain. Keep the existing root site on its current Worker. [Cloudflare Worker custom domains](https://developers.cloudflare.com/workers/configuration/routing/custom-domains/)

   ```powershell
   npx wrangler@4 login
   npx wrangler@4 whoami
   npx wrangler@4 r2 bucket create dysociate-published-threads
   npx wrangler@4 deploy
   ```

3. Create a dedicated publisher key with `python -c "import secrets; print(secrets.token_urlsafe(32))"`. Keep it in a password manager. Run `npx wrangler@4 secret put PUBLISH_KEY` and paste the key when prompted. Use the same key in the apps. Keep it out of the source, release archives, and shared threads. [Cloudflare Worker secrets](https://developers.cloudflare.com/workers/configuration/secrets/)
4. Check the hostname with `curl.exe -i https://threads.dysociate.org/healthz`. Expect `204 No Content`. Publish a disposable thread and open the resulting link on another device. Use **Remove link** to turn off that copy.

## Managing copies

The server accepts files up to 8 MiB and holds 256 active copies at once. Remove an older publication to make room. The app shows the most recent link in its publishing dialog. Windows remembers it for the open app session. Android remembers its most recently published link after restarting. A saved older URL can be removed from PowerShell. For a URL ending in `/t/<code>`, run `Invoke-RestMethod -Method Delete -Uri 'https://threads.dysociate.org/api/threads/<code>' -Authentication Bearer -Token (Read-Host 'Publisher key' -AsSecureString)` in PowerShell 7.

The link carries a random identifier and the service has no listing. Anyone who gets the URL can forward it. Removing a link stops the server from serving it. Copies already downloaded by others remain with them.

The storage cap keeps this bucket near 2 GiB even at capacity. Workers and R2 have separate request allowances, and R2 can charge for operations or account usage above its allowance. Keep the key within your trusted publishing group and monitor account usage before offering public uploads. [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) · [R2 pricing](https://developers.cloudflare.com/r2/pricing/)
