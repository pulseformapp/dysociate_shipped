// Copyright (c) 2026 Luna Love ~ LunaSoft
// SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

// The editor owns the one-use URL and receives the clip over loopback.
// This window only hosts that URL. The page can send one message to close it.
internal static class RecordReelWindow
{
    [STAThread]
    private static int Main(string[] args)
    {
        Uri capture;
        if (args.Length != 2 || !Uri.TryCreate(args[0], UriKind.Absolute, out capture)
            || capture.Scheme != "http" || capture.Host != "127.0.0.1"
            || !capture.AbsolutePath.StartsWith("/record/", StringComparison.Ordinal)
            || capture.UserInfo.Length != 0)
            return 2;

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        int result = 0;
        using (var window = new Form())
        using (var recorder = new WebView2())
        {
            window.Text = "Record reel · dλsociate";
            window.ClientSize = new Size(650, 620);
            window.MinimumSize = new Size(350, 360);
            window.StartPosition = FormStartPosition.CenterScreen;
            window.BackColor = Color.FromArgb(9, 5, 18);
            recorder.Dock = DockStyle.Fill;
            recorder.DefaultBackgroundColor = window.BackColor;
            window.Controls.Add(recorder);
            window.Shown += async delegate
            {
                try
                {
                    var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: args[1]);
                    await recorder.EnsureCoreWebView2Async(environment);
                    var view = recorder.CoreWebView2;
                    view.Settings.AreDevToolsEnabled = false;
                    view.Settings.AreDefaultContextMenusEnabled = false;
                    view.Settings.AreHostObjectsAllowed = false;
                    view.NewWindowRequested += (sender, request) => request.Handled = true;
                    view.WebMessageReceived += (sender, message) =>
                    {
                        if (message.Source == capture.AbsoluteUri && message.WebMessageAsJson == "\"close\"")
                            window.Close();
                    };
                    view.NavigationStarting += (sender, navigation) => navigation.Cancel = navigation.Uri != capture.AbsoluteUri;
                    view.PermissionRequested += (sender, request) =>
                    {
                        if (!Uri.TryCreate(request.Uri, UriKind.Absolute, out Uri origin)
                            || origin.GetLeftPart(UriPartial.Authority) != capture.GetLeftPart(UriPartial.Authority)
                            || (request.PermissionKind != CoreWebView2PermissionKind.Camera
                                && request.PermissionKind != CoreWebView2PermissionKind.Microphone))
                            request.State = CoreWebView2PermissionState.Deny;
                        request.SavesInProfile = false;
                    };
                    view.Navigate(capture.AbsoluteUri);
                }
                catch (Exception)
                {
                    if (window.IsDisposed) return;
                    result = 3;
                    MessageBox.Show(window, "The recorder could not start. Check that Microsoft Edge WebView2 Runtime is installed.",
                        "dλsociate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    window.Close();
                }
            };
            Application.Run(window);
        }
        return result;
    }
}
