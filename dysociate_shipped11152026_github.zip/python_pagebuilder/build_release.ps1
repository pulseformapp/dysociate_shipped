# dysociate - standalone Windows application build
# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

[CmdletBinding()]
param(
    [string]$Python,
    [string]$OutputDir,
    [string]$WebView2Sdk,
    [string]$NativeComposer,
    [switch]$OneDirectory
)

$ErrorActionPreference = "Stop"
$scriptDir = $PSScriptRoot
$recorder = Join-Path $scriptDir '..\dysociate_live\web\reel-recorder.js'
if (-not (Test-Path -LiteralPath $recorder)) { $recorder = Join-Path $scriptDir 'reel-recorder.js' }
if (-not $Python) { $Python = Join-Path $scriptDir '.venv\Scripts\python.exe' }
if (-not $OutputDir) { $OutputDir = Join-Path $scriptDir 'frozen\dist' }

# Reuse an existing environment, or create a private one for a source rebuild.
if (-not (Test-Path -LiteralPath $Python)) {
    $launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($launcher) { & $launcher.Source -3 -m venv (Join-Path $scriptDir '.venv') }
    else { & python -m venv (Join-Path $scriptDir '.venv') }
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the build environment.' }
}
& $Python -c 'import PyInstaller, PIL, pycdlib' 2>$null
if ($LASTEXITCODE -ne 0) {
    & $Python -m pip install -r (Join-Path $scriptDir 'requirements-build.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Build dependency installation failed.' }
}

# One-file mode extracts resources to a temporary folder. Embed the whole docs
# directory so Help (and its Word-manual link) works even if only the EXE is
# copied elsewhere. Installed builds prefer the persistent Documentation copy.
# Email uses only the standard library; do not bundle native sharing bindings.
$recorderDir = Join-Path $scriptDir 'frozen\recorder'
& (Join-Path $scriptDir 'build_recorder.ps1') -OutputDir $recorderDir -SdkDir $WebView2Sdk
& $Python (Join-Path $scriptDir 'build_offline_assets.py') $recorderDir
if ($LASTEXITCODE -ne 0) { throw 'Could not build the offline HTML shell.' }
$nativeArgs = if ($NativeComposer) { @('--add-binary', "$(Resolve-Path -LiteralPath $NativeComposer);native") } else { @() }
$layout = if ($OneDirectory) { '--onedir' } else { '--onefile' }
& $Python -m PyInstaller --noconfirm --clean $layout --windowed `
    --name dysociate `
    --icon (Join-Path $scriptDir 'assets\dysociate.ico') `
    --version-file (Join-Path $scriptDir 'version_info.txt') `
    --add-data "$(Join-Path $scriptDir 'assets');assets" `
    --add-data "$(Join-Path $scriptDir 'docs');docs" `
    --add-data "$(Join-Path $scriptDir 'LICENSE');." `
    --add-data "$(Join-Path $scriptDir 'browser_runtime.js');." `
    --add-data "$recorder;." `
    --add-data "$recorderDir;recorder" `
    --distpath $OutputDir `
    --workpath (Join-Path $scriptDir 'frozen\build') `
    --specpath (Join-Path $scriptDir 'frozen') `
    @nativeArgs `
    (Join-Path $scriptDir "dysociate_gui.py")
if ($LASTEXITCODE -ne 0) { throw 'dysociate executable build failed.' }

$exe = Join-Path $OutputDir $(if ($OneDirectory) { 'dysociate\dysociate.exe' } else { 'dysociate.exe' })
$test = Start-Process -FilePath $exe -ArgumentList '--self-test' -WindowStyle Hidden -Wait -PassThru
if ($test.ExitCode -ne 0) { throw 'The built executable did not pass its self-test.' }
Write-Output $exe
