"""Shared camera controls for the portable editor and Windows capture page.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

import sys
from pathlib import Path


REEL_LIMIT = 4 * 1024 * 1024
REEL_DIALOG = '''<dialog id="reel-recorder" class="terms-dialog reel-dialog" aria-label="Record reel">
<label data-reel-camera-picker hidden>Camera <select data-reel-camera></select></label>
<video data-reel-video playsinline></video>
<p data-reel-status role="status"></p>
<div class="comment-actions">
<button type="button" data-reel-record hidden>Record</button>
<button type="button" data-reel-stop hidden>Stop</button>
<button type="button" data-reel-use hidden>Use clip</button>
<button type="button" data-reel-retake hidden>Retake</button>
<button type="button" data-reel-cancel>Cancel</button>
</div>
</dialog>'''


def recorder_script():
    if hasattr(sys, '_MEIPASS'):
        path = Path(sys._MEIPASS) / 'reel-recorder.js'
    else:
        path = Path(__file__).resolve().parent.parent / 'dysociate_live' / 'web' / 'reel-recorder.js'
        if not path.is_file():
            path = Path(__file__).with_name('reel-recorder.js')
    return path.read_text(encoding='utf-8').replace('export function bindReelRecorder', 'function bindReelRecorder', 1)


def capture_page():
    return '''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Record reel · dλsociate</title>
<style>body,dialog{background:#090512;color:#ff76cf;font:1rem monospace}body{padding:1rem}
dialog{max-width:min(32rem,85vw);border:1px solid #b55b9d}video{display:block;width:100%;max-height:55vh}
button,select{min-height:44px;padding:.5rem;background:#2c1736;color:inherit;border:1px solid #b55b9d}
select{max-width:80%}</style></head>
<body><h1>Record reel</h1><button id="open">Open camera</button><p id="result" role="status"></p>''' + REEL_DIALOG + '''
<script>''' + recorder_script() + '''
const result = document.querySelector("#result");
const open = document.querySelector("#open");
const closeRecorder = () => window.chrome?.webview?.postMessage("close");
const camera = bindReelRecorder(document.querySelector("#reel-recorder"), async clip => {
    open.disabled = true;
    try {
        const reply = await fetch(location.pathname, {method: "POST", body: clip});
        if (!reply.ok) throw Error();
        closeRecorder();
    } catch {
        result.textContent = "The app could not receive the reel. Return to dλsociate to try again.";
    }
});
open.onclick = () => camera.open();
document.querySelector("[data-reel-cancel]").addEventListener("click", closeRecorder);
if (!camera.supported) {
    open.disabled = true;
    result.textContent = "This device cannot record MP4 reels.";
}
</script></body></html>'''
