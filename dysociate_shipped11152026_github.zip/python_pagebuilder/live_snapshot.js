/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
(() => {
    const api = "/api/v1/threads/" + location.pathname.slice(3);
    const maxBytes = 62 * 1024 * 1024;
    const limits = {"image/jpeg": 1024 ** 2, "image/png": 1024 ** 2, "video/mp4": 4 * 1024 ** 2};
    const started = {state: "pending", text: "Downloading history…"};
    let result = started;
    let metadata = "";
    const deadline = Date.now() + 5 * 60 * 1000;

    async function read(route = "", media) {
        if (Date.now() >= deadline) throw Error("The download timed out. Try again.");
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 20000);
        try {
            const response = await fetch(api + route, {
                credentials: "same-origin", redirect: "error", cache: "no-store", signal: controller.signal,
            });
            if (response.status === 401 || response.status === 403)
                throw Error("Join this thread before saving it.");
            if (!response.ok) throw Error("Could not download the whole thread. Try again.");
            if (media) {
                if (response.headers.get("Content-Type") !== media.type ||
                    (response.headers.has("Content-Length") &&
                        Number(response.headers.get("Content-Length")) !== media.size))
                    throw Error("A thread attachment changed. Save again to get the latest copy.");
                const blob = await response.blob();
                if (blob.size !== media.size) throw Error("An attachment did not finish downloading.");
                return await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = () => reject(Error("Could not embed a thread attachment."));
                    reader.readAsDataURL(blob);
                });
            }
            return await response.json();
        } finally {
            clearTimeout(timeout);
        }
    }

    async function collect() {
        // History pages can race with live posts or deletes. A second
        // watermark read verifies that every page and attachment belonged
        // to one stable version before the native app publishes the file.
        const start = await read();
        const pages = [start.posts];
        let count = start.posts.length;
        let before = start.olderCursor;
        while (before !== null) {
            const page = await read("/history?before=" + before);
            if (page.olderCursor !== null && !(page.olderCursor < before))
                throw Error("The thread returned an invalid history cursor.");
            before = page.olderCursor;
            pages.push(page.posts);
            count += page.posts.length;
            if (count > 10000) throw Error("This thread exceeds the offline editor's post limit.");
            result.text = "Downloading history · " + count + " posts";
        }
        const posts = pages.reverse().flat();
        const sections = [];
        const ids = new Set(posts.map(post => post.id));
        if (ids.size !== posts.length || posts.some(post => post.parentId && !ids.has(post.parentId)))
            throw Error("The full reply history could not be read. Try again.");
        let attachments = 0;
        let attachmentBytes = 0;
        for (const post of posts) {
            const section = {
                kind: "Post", post_id: post.id, parent_id: post.parentId || "",
                heading: post.deletedAt ? "Deleted post" : post.displayName || "Guest",
                body: post.deletedAt ? "[Post deleted]" : post.body || "",
            };
            if (!post.deletedAt && post.media) {
                const media = post.media;
                if (!Object.hasOwn(limits, media.type) || !Number.isSafeInteger(media.size) ||
                    media.size <= 0 || media.size > limits[media.type])
                    throw Error("A thread attachment is too large or uses an unsupported format.");
                attachmentBytes += media.size;
                if (attachmentBytes > 32 * 1024 * 1024)
                    throw Error("This thread is too large for the offline editor.");
                result.text = "Downloading attachments · " + (++attachments);
                const data = await read("/media/" + encodeURIComponent(post.id), media);
                section[media.type.startsWith("video/") ? "video_data_url" : "image_data_url"] = data;
            }
            sections.push(section);
        }
        if ((await read()).headSeq !== start.headSeq)
            throw Error("The thread changed while saving. Tap Save offline again.");
        // No invite, cookie, access secret or server author identifier goes
        // into the document. Escaping every '<' makes the JSON script-safe.
        const json = JSON.stringify({
            version: 1, title: start.thread.title, terminal_banner: "Offline copy",
            browser_editor_url: "", sections,
        }).replaceAll("<", "\\u003c");
        if (new TextEncoder().encode(json).length > maxBytes)
            throw Error("This thread is too large for the offline editor.");
        metadata = json;
        result = {state: "ready", title: start.thread.title};
    }

    const grab = Object.freeze({
        status: () => result,
        take(offset) {
            let end = Math.min(offset + 128 * 1024, metadata.length);
            if (end < metadata.length && /[\uD800-\uDBFF]/.test(metadata[end - 1])) end--;
            return metadata.slice(offset, end);
        },
        clear() { metadata = ""; },
    });
    window.dysociateOfflineCapture = grab;
    void collect().catch(error => {
        result = {state: "error", text: error.name === "AbortError" ? "The download timed out. Try again." : error.message};
    });
    return true;
})()
