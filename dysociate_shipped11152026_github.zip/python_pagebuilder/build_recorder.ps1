# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

param(
    [Parameter(Mandatory)][string]$OutputDir,
    [string]$SdkDir
)
$ErrorActionPreference = 'Stop'
$version = '1.0.3719.77'
if (-not $SdkDir) {
    $SdkDir = Join-Path $PSScriptRoot "frozen\webview2-$version"
    if (-not (Test-Path (Join-Path $SdkDir 'lib\net462\Microsoft.Web.WebView2.WinForms.dll'))) {
        New-Item -ItemType Directory -Force -Path $SdkDir | Out-Null
        $archive = Join-Path $SdkDir 'sdk.zip'
        $package = "https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/$version/microsoft.web.webview2.$version.nupkg"
        Invoke-WebRequest $package -OutFile $archive
        Expand-Archive -LiteralPath $archive -DestinationPath $SdkDir -Force
    }
}
$compiler = Get-Command csc.exe -ErrorAction SilentlyContinue
if (-not $compiler) {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    $install = & $vswhere -latest -products '*' -requires Microsoft.Component.MSBuild -property installationPath
    $compiler = Get-Command (Join-Path $install 'MSBuild\Current\Bin\Roslyn\csc.exe')
}
$core = Join-Path $SdkDir 'lib\net462\Microsoft.Web.WebView2.Core.dll'
$winforms = Join-Path $SdkDir 'lib\net462\Microsoft.Web.WebView2.WinForms.dll'
$loader = Join-Path $SdkDir 'runtimes\win-x64\native\WebView2Loader.dll'
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$helpers = @{ 'record-reel' = 'RecordReelWindow.cs'; 'live-thread' = 'LiveThreadWindow.cs' }
foreach ($name in $helpers.Keys) {
    $exe = Join-Path $OutputDir "$name.exe"
    $compileArgs = @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/codepage:65001',
        "/out:$exe", '/reference:System.Windows.Forms.dll', '/reference:System.Drawing.dll', '/reference:System.Web.Extensions.dll',
        "/reference:$core", "/reference:$winforms", (Join-Path $PSScriptRoot $helpers[$name]))
    & $compiler.Source @compileArgs
    if ($LASTEXITCODE -ne 0) { throw "Could not build $name.exe." }
}
Copy-Item -LiteralPath $core,$winforms,$loader -Destination $OutputDir -Force
Copy-Item -LiteralPath (Join-Path $SdkDir 'LICENSE.txt') -Destination (Join-Path $OutputDir 'WebView2-LICENSE.txt') -Force
