# dλsociate Live

The local Worker creates a Wild West thread from a title and an opening text post. Anyone with the invite can open the thread in a browser, post, and reply without an account. Open viewers see new posts and deletions as they happen. Each browser can delete its own posts. Replies to a deleted post stay in the history.

The thread and its operation receipts live in a SQLite Durable Object. A browser cookie establishes authorship. A disconnected viewer catches up using the last sequence it saw. An unfinished draft stays in that browser, and a retry with the same operation ID avoids a duplicate post. Windows and Android use the same API to create threads and delete their own opening posts. [Engineering specification](../dysociate-live-engineering-spec.md)

The Windows and Android apps can also host the live page in an embedded
viewer. The local Worker uses a test cookie on HTTP loopback port 8795
for Android WebView testing. The HTTPS services use the secure browser cookie.

## Run locally

Open PowerShell in this folder. The commands below generate a signing key for local use and keep test storage in a temporary folder. Use the same key and state directory when restarting.

```powershell
$qa = Join-Path $env:TEMP 'dysociate-live-phase0'
New-Item -ItemType Directory -Path $qa -Force | Out-Null
$localEnv = Join-Path $qa 'local.env'
if (-not (Test-Path -LiteralPath $localEnv)) {
    $key = node -p "require('node:crypto').randomBytes(32).toString('base64url')"
    'INVITE_KEYS=' + (ConvertTo-Json -Compress @{v1=$key}) | Set-Content -LiteralPath $localEnv -Encoding ascii
}
$env:WRANGLER_SEND_METRICS = 'false'
$env:WRANGLER_LOG_PATH = Join-Path $qa 'wrangler.log'
npx.cmd wrangler@4.160.0 dev --local --config wrangler.local.jsonc --ip 127.0.0.1 --port 8795 --env-file $localEnv --persist-to (Join-Path $qa 'state')
```

In a second PowerShell window in this folder, run the create test. It only accepts loopback and writes a receipt with synthetic local test data.

```powershell
$receipt = Join-Path $env:TEMP ('dysociate-live-test-' + [guid]::NewGuid().ToString('N') + '.json')
node tests/phase0.mjs create http://127.0.0.1:8795 $receipt
```

Stop the Worker with Ctrl+C and run the same `dev` command again in the first window. Verify the original link, post, and receipt from the second window.

```powershell
node tests/phase0.mjs restart http://127.0.0.1:8795 $receipt
```

Run the live API test and the headless browser test with the Worker running. The browser test opens two isolated Edge profiles and exercises posting, replies, deletion, and reconnect at desktop and phone viewport sizes. Both tests create synthetic threads in the local database.

```powershell
node tests/phase1.mjs http://127.0.0.1:8795
$edge = Join-Path ${env:ProgramFiles(x86)} 'Microsoft/Edge/Application/msedge.exe'
node tests/browser.mjs http://127.0.0.1:8795 $edge $env:TEMP
```

## v1 endpoints

| Route | Behavior |
| --- | --- |
| `GET /api/v1/health` | Returns 204 when the Worker is reachable. |
| `POST /api/v1/session` | Accepts `{"client":"native"}` and returns a bearer credential. `{"client":"browser"}` uses the same-origin request and issues or renews a private browser cookie. The browser creator can also send `"creation":true` to receive a fingerprint for checking that a retry still has the original browser session. |
| `POST /api/v1/threads` | Accepts the v1 create request. Send the native bearer credential or browser cookie. Returns 201 with the opening post and share URL. An identical retry returns 200 with the same result. |
| `GET /api/v1/threads/{invite}` | Returns the snapshot. An anonymous guest can read a valid Wild West invite. With a credential, it also returns the viewer's thread-specific author ID. |
| `GET /api/v1/threads/{invite}/history?before=...` | Returns older posts in creation order and a cursor for the next page. |
| `GET /api/v1/threads/{invite}/changes?after=...` | Returns current versions of changed posts, with `nextAfter` and `hasMore` for reconnect. |
| `POST /api/v1/threads/{invite}/posts` | Creates a post or a reply when `parentId` is supplied. Matching retries return the current post record. |
| `GET /api/v1/threads/{invite}/media/{postId}` | Returns the attachment for a readable post. Also supports `HEAD` and a single byte range for video playback. |
| `DELETE /api/v1/threads/{invite}/posts/{id}` | Deletes the caller's own post body and keeps a deletion marker so replies retain their parent. |
| `GET /api/v1/threads/{invite}/live` | Upgrades to a WebSocket and streams committed post changes after the initial `ready` message. |
| `GET /t/{invite}` | Opens the live thread and composer in the browser. |

### Phase 12A browser view

The current viewer uses `?view=groups` on snapshot, history, changes, post,
delete, and WebSocket requests. Snapshot and history in this view page through
root posts. The view adds stable root IDs, reply counts, and parent context.
The default flat view continues to serve all posts to earlier clients and the
offline exporter. Expand a group with `GET /branch/{rootId}?after=0` and use
the returned `nextAfter` for additional pages. `GET /target/{postId}` resolves
a reply and its root. A thread URL with `#post=<postId>` targets that post.

Use `GET /reactions?ids=<comma-separated post IDs>` for up to 50 live posts.
`PUT /like/{postId}` accepts `liked`, `actorRevision`, and `operationId`.
The grouped WebSocket can send `reaction.changed` with `postId` and `revision`.
Reactions have their own revisions and leave the post cursor alone.

With `ENABLE_WEB_AGREEMENTS=true`, `/t/new` opens after the browser accepts
the License Agreement and Karmic Law. `GET /api/v1/agreements` returns the
current wording, version, and creation acceptance status. Posting the current
version with `license` and `karmicLaw` set to `true` records both choices in a
signed cookie bound to the browser session. Shared links open for reading
under their existing access rules. The guest's first post or reply requires
both agreements on that thread. `GET` and `POST /agreement` under the thread
API show and record that thread's terms. Native credential calls and flat
history exports use the existing contract.

For local QA with agreements, add `--var ENABLE_WEB_AGREEMENTS:true` to
the Wrangler command above. Add `--var ENABLE_BROWSER_CREATE:true`,
`--var ENABLE_LOCKED:true`, `--var ENABLE_MEDIA:true`, and `--var ENABLE_REELS:true`
to cover all the browser flows. Run `tests/phase1.mjs` with `--agreements` and
run `tests/browser.mjs` with `--agreements` for each of the default, `--create`,
and `--locked` cases. The default case also accepts `--media` for photo and
simulated camera checks.

Phase 12A local verification covered the flat v1 contract and grouped reply
pagination, concurrent Likes, stale retries, locking, creator consent and
per-thread guest consent. Isolated Edge sessions exercised the mobile layout,
draft retention, direct reply links, missed updates after reconnect, and media.
A copy of the Phase 11 SQLite fixture retained its deleted root and nested
history, accepted a new reply, and exported the original photo and exact MP4
bytes through the Phase 11 snapshot code. The production Wrangler dry-run
built successfully. Physical Safari and Android checks remain release gates.

### Phase 12B Following and notifications

From a readable thread, open **Follow thread** and choose **Replies to me**,
**All activity**, or **Muted**. The Home Screen web app opens `/t/following`
and keeps the followed threads in that device's browser storage. On iPhone
or iPad, add dλsociate to the Home Screen, launch it from the icon, and open
the thread there before enabling alerts. Paste the invite once if the Home
Screen app has its own browser session. Locked threads still require access
in the session that follows. Android can enable alerts from a supported
system browser. [Apple WebKit](https://webkit.org/blog/13878/web-push-for-web-apps-on-ios-and-ipados/)

`GET`, `PUT`, and `DELETE /follow/{id}` under the thread API manage the
current anonymous browser's device subscription. Alert payloads carry an
opaque follow ID and post ID. Notification content omits thread titles,
invites, and post text. The service worker uses no content cache. A click
resolves the locally saved invite and opens the post through ordinary thread
access checks. Changing mode or unfollowing discards queued work. A locally
saved follow remains available while alerts are paused. After 90 days without
renewal, a server subscription stops sending. Open the follow panel and save
again to renew it. `404` and `410` from a provider retire the subscription.

The `v2` migration adds a single SQLite-backed Durable Object for the send
budget. No R2 binding is required. The pilot defaults to 1,000 attempts per
UTC day across threads on that Worker, 24 enrolled devices per thread, and
five seconds of coalescing per thread and device. A queued alert expires after
five minutes and can make up to three attempts. A successful provider response
counts as accepted, with device receipt verified separately. Configure
`PAUSE_PUSH=true` to stop new sends and discard queued alerts. Regular thread
reads, posts, and browser updates work with delivery paused.

For a deployed pilot, generate a fresh key set for that origin using
`node push-keygen.mjs <new-secret-file> https://dysociate.org`. Keep the JSON
outside source packages and upload it as Wrangler bulk secrets to the
isolated pilot Worker. Keep the private key stable across deployments so
installed subscriptions continue to work. The Worker serves only the public
key to browsers. Enable Web Push on that pilot with `ENABLE_WEB_PUSH=true`
after installing the keys. Keep production alerts disabled while checking
physical devices. The shipping Worker uses [RFC 8291](https://www.rfc-editor.org/rfc/rfc8291.html)
and [RFC 8292](https://www.rfc-editor.org/rfc/rfc8292.html).

Run `node tests/push.mjs <Wrangler node_modules> <pilot dry-run worker.js>`
to exercise the encryption vector and local Durable Object alarms with all
provider traffic intercepted. Run `tests/browser.mjs` with `--following`
for the saved-thread and deep-link regression. For device acceptance, start
from a shared message on a physical iPhone and Android. Follow, put the device
to sleep, send a reply from a second device, and tap the resulting alert.
Check both notification modes, mute, and a locked thread from a separate
profile. Record recipient, timestamp, and whether the exact reply opened.

Local verification passed the RFC encryption vector and real Durable Object
alarms with an intercepted provider. The test decoded each payload, verified
its VAPID signature, and exercised coalescing, retries, expired subscriptions,
the send budget, and locked access. Edge verified Following, muted saves,
unfollow, and opening a specific post from its opaque notification target.

Hosted pilot version `f93d6589-af78-45cf-a062-dad7fad32db5` passed HTTPS checks
for the manifest, service worker, browser agreements, public push key, and
follow API. Two isolated Edge sessions also passed Following, reply navigation,
and reconnect checks on that deployment. Physical iPhone and Android push
delivery from that pilot still needs to be recorded.

Pilot version `8f1d8885-9ef5-42c9-9e94-afe915bc9b33` requests high urgency
from FCM and re-alerts when a new post replaces an existing notification for
the same follow. An identical redelivery is suppressed while its alert is
still present. The service worker activates updates with existing tabs open.
The loopback Chromium check `tests/browser.mjs --push-background` uses
DevTools to freeze the live thread tab and inject two simulated push events.
Both alerts displayed and the second kept the same tag and the new post ID.
For physical Android acceptance, leave the thread open in Chrome, switch to
another app, and send a fresh reply from a second browser profile. Repeat
without dismissing the first alert. Check the notification shade and tap the
new alert to confirm the exact reply opens.

## Locked access

Create accepts `accessMode: "locked"` and an optional `passkey` when
`ENABLE_LOCKED=true`. A passkey accepts at least eight characters and at
most 128 UTF-8 bytes. The Worker stores a room-specific keyed verifier and
rate-limits guesses at both the edge and the thread. Existing links and
creation receipts retain their Wild West format.

| Route under `/api/v1/threads/{invite}` | Behavior |
| --- | --- |
| `GET /access` | Returns the caller's state, role, and whether the passkey option is available. |
| `POST /join` | Takes an optional `name` and `passkey`. A matching passkey grants access. Without one, the request stays pending. |
| `GET /requests` | Lists pending requests for the creator. |
| `POST /requests/{id}` | Creator approves or declines a pending request with `decision`. |
| `POST /handoff` | The original app creates a five-minute, single-use creator URL from an empty JSON object. |
| `POST /claim` | The creator browser redeems the URL fragment using `token` and its same-origin session. |

The browser removes the handoff fragment before opening the thread. Only
the token digest is stored, and redemption and the browser grant commit
together. The browser grant is scoped to that thread and does not transfer
the native app's identity. Members and creators still delete only their
own posts. The Durable Object checks admission before snapshot, history,
changes, media, posting, deletion, and WebSocket upgrade.

Locked invitations have a separate signed `l-` prefix. Older Worker builds
reject that prefix before accessing storage, so rolling back does not open a
locked thread. Access tables are additive and the original post data can
remain in place. [Durable Object migrations](https://developers.cloudflare.com/durable-objects/reference/durable-objects-migrations/)

The invite contains a signing key ID, a 128-bit room ID, and an HMAC tag. The service rejects modified links before accessing SQLite. The create request has a stable operation ID, so two matching submissions select one object and return one link. A retry with different content returns 409.

[v1 schema](contract/v1.schema.json) · [Shared fixtures](contract/v1.fixtures.json)

## Photos and reels

When the host enables attachments, create and post also accept multipart
requests. Send the same request JSON as the `payload` field and one file as
`media`. The body may be empty when the file is present. JPEG and PNG are
limited to 1 MiB and 12 megapixels, with neither side exceeding 4,096 pixels.
Reels are H.264 MP4 with optional AAC audio, up to 4 MiB and 30 seconds.
An opening post, a top-level post, or a reply may have an attachment. Each
thread has a 32 MiB attachment budget.

The service checks the file before forwarding it to the thread. The SQLite
transaction stores the post, metadata, and 1 MiB chunks together. A live event
carries the post and its attachment metadata. Viewers fetch the media through
the invite only when they need it. This gives immediate reads in the same
transactional store. KV caches can take time to reflect updates or deletion.
Author deletion removes the chunks and leaves a tombstone for the replies.
[SQLite limits](https://developers.cloudflare.com/durable-objects/platform/limits/) ·
[KV consistency](https://developers.cloudflare.com/kv/concepts/how-kv-works/#consistency)

The production and pilot configs enable `ENABLE_MEDIA` and `ENABLE_REELS`.
The caps bound storage within a thread. Account-wide request and storage
limits also apply.

## Hosted pilot

`wrangler.pilot.jsonc` deploys a separate Worker and SQLite namespace to
`dysociate-live-pilot.pulseform.workers.dev`. The pilot has its own invitation
signing key. Pilot links stay on that host and use its thread history. Use
synthetic content when testing. [Pilot builds and test steps](../dysociate_live_phase5/README.md)

The pilot and production configurations apply edge limits of 25 new sessions,
8 create requests, 60 post requests, and 60 delete requests per source address
and Cloudflare location per minute. The per-thread SQLite transaction allows
60 new posts per fixed minute. At sequence 2,000, history remains readable and
authors can still delete their posts. `PAUSE_WRITES=true` returns a temporary
503 for authorized mutations while leaving history readable. Cloudflare edge
limits are approximate. [Cloudflare rate limiting](https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/)

## Production configuration

`wrangler.jsonc` defines the live `dysociate.org/t/*` and `dysociate.org/api/v1/*` routes. It binds a SQLite Durable Object and uses a separate `INVITE_KEYS` secret for the production signing keys. Keep previously issued signing keys available while their links are supported. The snapshot publishing service has its own configuration.

The Workers dashboard showed the Free allowance of 100,000 requests per day on November 11, 2026. At the Phase 3 preflight, the zone route list was empty and `dysociate.org` was assigned to `round-sky-1ff6` as a custom domain. The Wrangler OAuth session can list routes. Billing reads require a billing scope. [Workers dashboard](https://dash.cloudflare.com/e7b2f6ba8813c4f909bf25a4f064744c/workers-and-pages) · [Workers Free limits](https://developers.cloudflare.com/workers/platform/limits/#daily-requests)

The release checks verified the homepage and artwork against their pre-launch hashes, a native-client production invitation, live replies in two browser sessions, and reconnect with a saved draft. Cloudflare reported `request_limit_fail_open: false` for both live routes. [Cloudflare route behavior at the request limit](https://developers.cloudflare.com/workers/platform/limits/#daily-requests)

## Browser creation

`/t/new` opens the same-origin composer when `ENABLE_BROWSER_CREATE` is true.
It silently obtains a session and sends the same create request as a native client.
It records the operation ID in tab storage before sending the request. If the
server commits the thread and the response is lost, continuing with the same
draft and browser session returns that thread's original URL. A changed browser
session cannot recover that operation. A locked draft with a passkey needs the
same passkey again on retry. The composer never puts the passkey in tab storage.

With locked access enabled, the form offers Wild West and locked threads.
The live thread view handles photos and reels after creation.

Validate updates with Wrangler's dry run. [Cloudflare dry-run option](https://developers.cloudflare.com/workers/wrangler/commands/#deploy)

```powershell
$env:WRANGLER_LOG_PATH = Join-Path $env:TEMP 'dysociate-live-dry-run.log'
npx.cmd wrangler@4.160.0 deploy --config wrangler.jsonc --dry-run --outdir (Join-Path $env:TEMP 'dysociate-live-dry-run')
```
