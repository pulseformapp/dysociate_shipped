/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {pushAvailable, sendPush} from "./push.mjs";

export const pushSchema = `
    CREATE TABLE IF NOT EXISTS follows (
        follow_id TEXT PRIMARY KEY, actor_id TEXT NOT NULL, mode TEXT NOT NULL,
        endpoint TEXT NOT NULL UNIQUE, p256dh TEXT NOT NULL, auth TEXT NOT NULL,
        updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS push_outbox (
        follow_id TEXT PRIMARY KEY, post_id TEXT NOT NULL, reply_to TEXT,
        due INTEGER NOT NULL, expires INTEGER NOT NULL, attempts INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS push_totals (status TEXT PRIMARY KEY, count INTEGER NOT NULL);
`;

const followerLimit = 24;
const batchSize = 6;
const coalesceMs = 5000;
const lifetimeMs = 300000;
const followLifetimeMs = 90 * 86400000;

export class ThreadPush {
    constructor(thread, env) {
        this.thread = thread;
        this.storage = thread.storage;
        this.sql = thread.sql;
        this.env = env;
    }

    remove(followId) {
        this.sql.exec("DELETE FROM follows WHERE follow_id = ?", followId);
        this.sql.exec("DELETE FROM push_outbox WHERE follow_id = ?", followId);
    }

    follow({followId, actorId, subscription, mode}) {
        return this.storage.transactionSync(() => {
            const existing = this.sql.exec("SELECT * FROM follows WHERE follow_id = ?", followId).toArray()[0];
            if (existing && existing.actor_id !== actorId) return Response.json({error: {
                code: "follow_session_changed", message: "This follow belongs to an earlier session. Remove it and follow again."}}, {status: 409});
            if (mode === "remove") {
                this.remove(followId);
                return Response.json({mode: null});
            }
            const now = Date.now();
            if (mode === "status") return Response.json({mode: existing?.updated_at >= now - followLifetimeMs ? existing.mode : null});
            if (mode === "muted") {
                if (existing) this.sql.exec("UPDATE follows SET mode = ?, updated_at = ? WHERE follow_id = ?", mode, now, followId);
                this.sql.exec("DELETE FROM push_outbox WHERE follow_id = ?", followId);
                return Response.json({mode});
            }
            // An endpoint belongs to the latest enrollment on this device.
            // Remove a previous enrollment only after a valid subscription is presented.
            const duplicate = this.sql.exec("SELECT follow_id, p256dh, auth FROM follows WHERE endpoint = ?", subscription.endpoint).toArray()[0];
            if (duplicate && duplicate.follow_id !== followId) {
                if (duplicate.p256dh !== subscription.p256dh || duplicate.auth !== subscription.auth)
                    return Response.json({error: {code: "subscription_conflict", message: "Reconnect this browser's notification subscription."}}, {status: 409});
                this.remove(duplicate.follow_id);
            }
            for (const row of this.sql.exec("SELECT follow_id FROM follows WHERE updated_at < ?", now - followLifetimeMs)) {
                this.remove(row.follow_id);
            }
            if ((!existing || existing.updated_at < now - followLifetimeMs) && this.sql.exec("SELECT COUNT(*) AS n FROM follows").one().n >= followerLimit) {
                return Response.json({error: {code: "follow_capacity", message: "This pilot thread has reached its notification limit."}}, {status: 409});
            }
            this.sql.exec(`INSERT INTO follows VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(follow_id) DO UPDATE SET
                mode = excluded.mode, endpoint = excluded.endpoint, p256dh = excluded.p256dh,
                auth = excluded.auth, updated_at = excluded.updated_at`, followId, actorId, mode,
                subscription.endpoint, subscription.p256dh, subscription.auth, now);
            if (!existing || existing.mode !== mode || existing.endpoint !== subscription.endpoint ||
                existing.p256dh !== subscription.p256dh || existing.auth !== subscription.auth) this.sql.exec("DELETE FROM push_outbox WHERE follow_id = ?", followId);
            return Response.json({mode});
        });
    }

    enqueue(postId, authorId, parentId) {
        if (!pushAvailable(this.env) || this.env.PAUSE_PUSH === "true") return 0;
        const now = Date.now();
        const parent = parentId && this.sql.exec("SELECT author_id FROM posts WHERE id = ? AND deleted_at IS NULL", parentId).toArray()[0];
        // Coalesce per device and thread. Keep the original window bounded
        // while replacing the target with the newest matching committed post.
        const rows = this.sql.exec(`INSERT INTO push_outbox
            SELECT follow_id, ?, ?, ?, ?, 0 FROM follows
            WHERE actor_id != ? AND updated_at >= ? AND (mode = 'all' OR (mode = 'replies' AND actor_id = ?))
            ON CONFLICT(follow_id) DO UPDATE SET post_id = excluded.post_id, reply_to = excluded.reply_to,
            due = CASE WHEN push_outbox.expires > ? THEN push_outbox.due ELSE excluded.due END,
            expires = CASE WHEN push_outbox.expires > ? THEN push_outbox.expires ELSE excluded.expires END,
            attempts = CASE WHEN push_outbox.expires > ? THEN push_outbox.attempts ELSE 0 END
            RETURNING follow_id`, postId, parent?.author_id ?? null, now + coalesceMs, now + lifetimeMs,
            authorId, now - followLifetimeMs, parent?.author_id ?? null, now, now, now).toArray();
        return rows.length;
    }

    async schedule() {
        const due = this.sql.exec("SELECT MIN(due) AS due FROM push_outbox").one().due;
        if (due === null) return;
        const scheduled = await this.storage.getAlarm();
        if (scheduled === null || due < scheduled) await this.storage.setAlarm(due);
    }

    count(status) {
        this.sql.exec("INSERT INTO push_totals VALUES (?, 1) ON CONFLICT(status) DO UPDATE SET count = count + 1", status);
    }

    finish(job) {
        this.sql.exec("DELETE FROM push_outbox WHERE follow_id = ? AND post_id = ?", job.follow_id, job.post_id);
    }

    current(job) {
        const row = this.sql.exec(`SELECT follows.*, push_outbox.post_id FROM follows JOIN push_outbox USING(follow_id)
            JOIN posts ON posts.id = push_outbox.post_id WHERE follows.follow_id = ? AND posts.deleted_at IS NULL`, job.follow_id).toArray()[0];
        return row && row.post_id === job.post_id && row.endpoint === job.endpoint && row.p256dh === job.p256dh && row.auth === job.auth &&
            row.updated_at >= Date.now() - followLifetimeMs &&
            (row.mode === "all" || (row.mode === "replies" && row.actor_id === job.reply_to)) &&
            (["open", "approved"].includes(this.thread.access(this.thread.threadRow(), row.actor_id).state));
    }

    async deliver(job) {
        if (job.expires <= Date.now() || job.attempts >= 3 || !this.current(job)) return this.finish(job);
        let result;
        try {
            const budget = this.env.PUSH_BUDGET.get(this.env.PUSH_BUDGET.idFromName("daily"));
            const slot = await budget.fetch("https://push-budget.internal/", {method: "POST"});
            if (slot.status === 429) {
                this.count("budget");
                return this.finish(job);
            }
            if (!slot.ok) throw Error();
            if (!this.current(job) || job.expires <= Date.now()) return this.finish(job);
            result = await sendPush(this.env, job, Math.ceil((job.expires - Date.now()) / 1000));
        } catch { result = {status: 503, retryAfter: 0}; }
        const {status, retryAfter} = result;
        if (status === 404 || status === 410) {
            this.count("gone");
            const current = this.sql.exec("SELECT updated_at FROM follows WHERE follow_id = ? AND endpoint = ?",
                job.follow_id, job.endpoint).toArray()[0];
            if (current?.updated_at === job.updated_at) this.remove(job.follow_id);
            else this.finish(job);
        } else if (status >= 200 && status < 300) {
            this.count("accepted");
            this.finish(job);
        } else if (status === 429 || status >= 500) {
            this.count("retryable");
            const due = Date.now() + Math.max(retryAfter, 15000 * 2 ** job.attempts);
            if (job.attempts >= 2 || due >= job.expires) this.finish(job);
            else this.sql.exec("UPDATE push_outbox SET due = ?, attempts = attempts + 1 WHERE follow_id = ? AND post_id = ?",
                due, job.follow_id, job.post_id);
        } else {
            this.count("rejected");
            this.finish(job);
        }
    }

    async alarm() {
        if (!pushAvailable(this.env) || this.env.PAUSE_PUSH === "true") {
            this.sql.exec("DELETE FROM push_outbox");
            return;
        }
        const jobs = this.sql.exec("SELECT * FROM push_outbox JOIN follows USING(follow_id) WHERE due <= ? ORDER BY due LIMIT ?",
            Date.now(), batchSize).toArray();
        // One alarm owns delivery. Schedule the next batch after the current
        // sends settle. Fresh writes can enqueue while fetch is in flight.
        await Promise.all(jobs.map(job => this.deliver(job)));
        await this.schedule();
    }
}
