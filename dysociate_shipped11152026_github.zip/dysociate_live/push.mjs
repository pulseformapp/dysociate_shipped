/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

const encoder = new TextEncoder();
const curve = {name: "ECDH", namedCurve: "P-256"};
export const modes = ["replies", "all", "muted"];
export const followPattern = /^[A-Za-z0-9_-]{43}$/;

function b64(bytes) {
    return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}

function decode(value, size) {
    if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value) || value.length !== Math.ceil(size * 8 / 6)) throw Error();
    const bytes = Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), char => char.charCodeAt(0));
    if (bytes.length !== size || b64(bytes) !== value) throw Error();
    return bytes;
}

function providerURL(endpoint) {
    if (typeof endpoint !== "string" || endpoint.length > 2048) throw Error();
    const url = new URL(endpoint);
    const host = url.hostname;
    const permitted = host === "fcm.googleapis.com" || host === "updates.push.services.mozilla.com" ||
        host === "push.apple.com" || host.endsWith(".push.apple.com");
    if (!permitted || url.protocol !== "https:" || url.port || url.username || url.password || url.hash ||
        (host === "fcm.googleapis.com" && !url.pathname.startsWith("/fcm/send/")) || url.pathname === "/") throw Error();
    return url;
}

export async function checkSubscription(subscription) {
    const endpoint = providerURL(subscription?.endpoint).href;
    const {p256dh, auth} = subscription.keys || {};
    decode(auth, 16);
    // Importing the point validates that it lies on P-256 before persisting it.
    await crypto.subtle.importKey("raw", decode(p256dh, 65), curve, false, []);
    return {endpoint, p256dh, auth};
}

export function pushAvailable(env) {
    return env.ENABLE_WEB_PUSH === "true" && Boolean(env.PUSH_VAPID_PRIVATE_JWK && env.PUSH_VAPID_PUBLIC_KEY && env.PUSH_VAPID_SUBJECT);
}

function concat(...pieces) {
    const result = new Uint8Array(pieces.reduce((total, part) => total + part.length, 0));
    let offset = 0;
    for (const part of pieces) { result.set(part, offset); offset += part.length; }
    return result;
}

async function hkdf(key, salt, info, bytes) {
    const handle = await crypto.subtle.importKey("raw", key, "HKDF", false, ["deriveBits"]);
    return new Uint8Array(await crypto.subtle.deriveBits({name: "HKDF", hash: "SHA-256", salt, info}, handle, bytes * 8));
}

export async function encryptPush({p256dh, auth}, payload, options = {}) {
    const receiver = decode(p256dh, 65);
    const peer = await crypto.subtle.importKey("raw", receiver, curve, false, []);
    const {publicKey, privateKey} = options.keyPair || await crypto.subtle.generateKey(curve, true, ["deriveBits"]);
    const sender = new Uint8Array(await crypto.subtle.exportKey("raw", publicKey));
    const shared = await crypto.subtle.deriveBits({name: "ECDH", public: peer}, privateKey, 256);
    const salt = options.salt || crypto.getRandomValues(new Uint8Array(16));
    // RFC 8291 binds both ECDH public keys to the subscription secret. The
    // second HKDF uses the record salt to derive separate key and nonce values.
    const input = await hkdf(shared, decode(auth, 16), concat(encoder.encode("WebPush: info\0"), receiver, sender), 32);
    const rawKey = await hkdf(input, salt, encoder.encode("Content-Encoding: aes128gcm\0"), 16);
    const nonce = await hkdf(input, salt, encoder.encode("Content-Encoding: nonce\0"), 12);
    const key = await crypto.subtle.importKey("raw", rawKey, {name: "AES-GCM"}, false, ["encrypt"]);
    const plaintext = encoder.encode(payload);
    if (plaintext.length > 3993) throw Error("Push payload exceeds one record.");
    const ciphertext = await crypto.subtle.encrypt({name: "AES-GCM", iv: nonce}, key, concat(plaintext, Uint8Array.of(2)));
    return concat(salt, Uint8Array.of(0, 0, 16, 0, sender.length), sender, new Uint8Array(ciphertext));
}

const jwtHeader = b64(encoder.encode(JSON.stringify({typ: "JWT", alg: "ES256"})));

export async function vapidAuthorization(env, audience) {
    const claims = {aud: audience, exp: Math.floor(Date.now() / 1000) + 3600, sub: env.PUSH_VAPID_SUBJECT};
    const content = jwtHeader + "." + b64(encoder.encode(JSON.stringify(claims)));
    const privateKey = await crypto.subtle.importKey("jwk", JSON.parse(env.PUSH_VAPID_PRIVATE_JWK),
        {name: "ECDSA", namedCurve: "P-256"}, false, ["sign"]);
    const signature = await crypto.subtle.sign({name: "ECDSA", hash: "SHA-256"}, privateKey, encoder.encode(content));
    return "vapid t=" + content + "." + b64(new Uint8Array(signature)) + ", k=" + env.PUSH_VAPID_PUBLIC_KEY;
}

export async function sendPush(env, job, ttl) {
    const endpoint = providerURL(job.endpoint);
    // The phone resolves the opaque follow ID using its own saved list. The
    // payload contains no invite, display name, title, or message text.
    const [body, authorization] = await Promise.all([
        encryptPush(job, JSON.stringify({followId: job.follow_id, postId: job.post_id})),
        vapidAuthorization(env, endpoint.origin),
    ]);
    // Manual redirect handling keeps a provider from forwarding the payload
    // or VAPID authorization to a host outside the validated allowlist.
    const response = await fetch(endpoint, {method: "POST", redirect: "manual", signal: AbortSignal.timeout(5000), body,
        headers: {Authorization: authorization, "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream",
            // Request timely delivery for Chrome's device alerts during
            // Android background/battery scheduling. Keep the existing APNs
            // and Mozilla delivery priorities.
            "TTL": String(ttl), Urgency: endpoint.hostname === "fcm.googleapis.com" ? "high" : "normal",
            Topic: job.follow_id.slice(0, 32)}});
    const delay = response.headers.get("Retry-After");
    const retryAfter = delay && (/^\d+$/.test(delay) ? Number(delay) * 1000 : Date.parse(delay) - Date.now());
    await response.body?.cancel();
    return {status: response.status, retryAfter: Number.isFinite(retryAfter) ? retryAfter : 0};
}

// One account-side allowance covers every thread. A provider attempt always
// consumes its slot, including timeouts and retries. This limits burst load
// on Free independently of the per-thread limits and provider acceptance.
export class PushBudget {
    constructor(state, env) {
        this.storage = state.storage;
        this.env = env;
        this.storage.sql.exec("CREATE TABLE IF NOT EXISTS budget (singleton INTEGER PRIMARY KEY, day INTEGER, used INTEGER)");
    }

    async fetch(request) {
        if (request.method !== "POST") return new Response(null, {status: 405});
        const configured = Number(this.env.PUSH_DAILY_LIMIT ?? 1000);
        const limit = Number.isSafeInteger(configured) && configured >= 0 ? configured : 0;
        const sql = this.storage.sql;
        const day = Math.floor(Date.now() / 86400000);
        const allowed = this.storage.transactionSync(() => {
            const row = sql.exec("SELECT used FROM budget WHERE singleton = 1 AND day = ?", day).toArray()[0];
            const used = row?.used || 0;
            if (used >= limit) return false;
            sql.exec("INSERT OR REPLACE INTO budget VALUES (1, ?, ?)", day, used + 1);
            return true;
        });
        return new Response(null, {status: allowed ? 204 : 429});
    }
}
