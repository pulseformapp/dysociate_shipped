/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {inviteFrom, savedThreads, removeFollow, modeLabels} from "./follow.js";

const list = document.getElementById("follow-list");
const status = document.getElementById("following-status");
function openNotification() {
    const target = /^#open=([A-Za-z0-9_-]{43})\.(p_[A-Za-z0-9_-]{22})$/.exec(location.hash);
    if (!target) return;
    const entry = savedThreads().find(item => item.id === target[1]);
    history.replaceState(null, "", location.pathname);
    if (entry) location.replace(entry.path + "#post=" + target[2]);
    else status.textContent = "This notification's thread is no longer saved on this device.";
}
window.addEventListener("hashchange", openNotification);
openNotification();

function render() {
    list.replaceChildren();
    const entries = savedThreads();
    if (!entries.length) list.textContent = "No followed threads yet. Open a thread and choose Follow thread.";
    for (const entry of entries) {
        const card = document.createElement("article");
        const link = document.createElement("a");
        link.href = entry.path;
        link.textContent = entry.title;
        const mode = document.createElement("p");
        mode.textContent = modeLabels[entry.mode];
        const remove = document.createElement("button");
        remove.textContent = "Unfollow";
        remove.addEventListener("click", async () => {
            remove.disabled = true;
            try { await removeFollow(entry); render(); }
            catch (error) { status.textContent = error.message; remove.disabled = false; }
        });
        card.append(link, mode, remove);
        list.append(card);
    }
}

document.getElementById("open-invite").addEventListener("submit", event => {
    event.preventDefault();
    const path = inviteFrom(document.getElementById("invite").value.trim());
    if (path) location.assign(path);
    else status.textContent = "Paste a thread link from this dλsociate site.";
});
window.addEventListener("storage", render);
window.addEventListener("pageshow", render);
render();
