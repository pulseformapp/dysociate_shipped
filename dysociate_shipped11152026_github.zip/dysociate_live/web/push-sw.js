/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

// Deliberately no fetch handler. The service worker never caches thread data.
// Activate notification fixes even when a thread tab stays open.
self.addEventListener("install", event => event.waitUntil(self.skipWaiting()));
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));

self.addEventListener("push", event => {
    let data;
    try { data = event.data?.json(); } catch { return; }
    if (!/^[A-Za-z0-9_-]{43}$/.test(data?.followId || "") || !/^p_[A-Za-z0-9_-]{22}$/.test(data?.postId || "")) return;
    event.waitUntil(showActivity(data.followId, data.postId));
});

async function showActivity(followId, postId) {
    const visible = await self.registration.getNotifications?.({tag: followId}).catch(() => []) ?? [];
    if (visible.some(alert => alert.data?.postId === postId)) return;
    // Chrome replaces an existing notification with the same tag silently
    // by default. Request an alert for new posts while keeping one card per
    // follow, independent of the state of any open thread tab.
    await self.registration.showNotification("dλsociate", {
        body: "New activity in a thread you follow.", icon: "/t/_assets/icon-192.png",
        tag: followId, renotify: true, data: {followId, postId},
    });
}

self.addEventListener("notificationclick", event => {
    event.notification.close();
    const data = event.notification.data;
    const target = new URL("/t/following", self.location.origin);
    if (/^[A-Za-z0-9_-]{43}$/.test(data?.followId || "") && /^p_[A-Za-z0-9_-]{22}$/.test(data?.postId || ""))
        target.hash = "open=" + data.followId + "." + data.postId;
    // Open a separate view so a notification cannot replace a live draft.
    event.waitUntil(self.clients.openWindow(target.href));
});
