/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {browserSession, request} from "./thread-client.js";

const invitePath = /^\/t\/(?:l-)?[a-z0-9]{1,12}\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}$/;
const storeKey = "dysociate-following-v1";
export const modeLabels = {replies: "Replies to me", all: "All activity", muted: "Muted"};

export function inviteFrom(value) {
    try {
        const url = new URL(value, location.origin);
        return url.origin === location.origin && invitePath.test(url.pathname) ? url.pathname : null;
    } catch { return null; }
}

export function savedThreads() {
    try {
        const items = JSON.parse(localStorage.getItem(storeKey) || "[]");
        return items.filter(item => invitePath.test(item.path) && /^[A-Za-z0-9_-]{43}$/.test(item.id) &&
            typeof item.title === "string" && Object.hasOwn(modeLabels, item.mode));
    } catch { return []; }
}

function store(item, remove = false) {
    const items = savedThreads().filter(entry => entry.path !== item.path);
    if (!remove) items.unshift(item);
    localStorage.setItem(storeKey, JSON.stringify(items));
}

const b64 = bytes => btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
const keyBytes = key => Uint8Array.from(atob(key.replaceAll("-", "+").replaceAll("_", "/")), char => char.charCodeAt(0));
const endpoint = item => "/api/v1/threads/" + item.path.slice(3) + "/follow/" + item.id;

export async function removeFollow(item) {
    await browserSession();
    try { await request(endpoint(item), "DELETE"); }
    catch (error) { if (error.code !== "follow_session_changed") throw error; }
    store(item, true);
    // Releasing the last device subscription also stops a stale server
    // enrollment if the browser session was lost or reset.
    if (!savedThreads().some(entry => entry.mode !== "muted") && "serviceWorker" in navigator) {
        try {
            const worker = await navigator.serviceWorker.getRegistration("/t/");
            const active = await worker?.pushManager?.getSubscription();
            await active?.unsubscribe();
        } catch { /* The acknowledged server removal already stops delivery. */ }
    }
}

function isAppleMobile() {
    return /iPhone|iPad|iPod/.test(navigator.userAgent) ||
        (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

export function installHint() {
    return isAppleMobile() && !navigator.standalone && !matchMedia("(display-mode: standalone)").matches
        ? "In Safari, tap Share → Add to Home Screen. Open dλsociate from its icon, then paste this thread link if needed." : "";
}

export function bindFollow(client) {
    const panel = document.getElementById("follow-panel");
    const toggle = document.getElementById("follow-thread");
    const mode = document.getElementById("follow-mode");
    const save = document.getElementById("save-follow");
    const remove = document.getElementById("remove-follow");
    const status = document.getElementById("follow-status");
    const copy = document.getElementById("follow-copy");
    const path = location.pathname;
    let item = savedThreads().find(entry => entry.path === path);
    let registration, subscription, registrationTask, saving = false;

    function showState() {
        toggle.textContent = item ? "Following ✓" : "Follow thread";
        remove.hidden = !item;
        mode.value = item?.mode || (supported && client.pushKey ? "replies" : "muted");
    }

    const hint = installHint();
    const supported = !hint && "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
    const prepare = async () => {
        if (hint) { status.textContent = hint; copy.hidden = false; }
        else if (!supported) status.textContent = "You can save this thread here. Open the link in a supported browser to enable alerts.";
        else if (!client.pushKey) status.textContent = "Phone alerts are paused here. You can still save this thread to Following.";
        else if (Notification.permission === "denied") status.textContent = "Notifications are blocked. Allow them in browser settings, then return here.";
        else {
            try {
                await navigator.serviceWorker.register("/t/push-sw.js", {scope: "/t/"});
                registration = await navigator.serviceWorker.ready;
                subscription = await registration.pushManager.getSubscription();
                if (item?.mode && item.mode !== "muted") {
                    const state = subscription && await request(endpoint(item));
                    if (!state?.mode) status.textContent = "Alerts are disconnected. Save again to reconnect this device.";
                    else if (state.mode !== item.mode) status.textContent = "Save again to update the alert mode.";
                }
            } catch { status.textContent = "The browser could not prepare notifications. You can still follow with alerts muted."; }
        }
        if ((!supported || !client.pushKey || !registration || Notification.permission === "denied") && !item) mode.value = "muted";
    };

    toggle.hidden = false;
    showState();
    toggle.addEventListener("click", () => {
        panel.hidden = !panel.hidden;
        toggle.setAttribute("aria-expanded", String(!panel.hidden));
        if (panel.hidden) return;
        const share = document.getElementById("share");
        if (share.getAttribute("aria-expanded") === "true") share.click();
        status.textContent = "";
        registrationTask = prepare();
        mode.focus();
    });
    window.addEventListener("storage", () => {
        if (saving) return;
        item = savedThreads().find(entry => entry.path === path);
        showState();
    });
    copy.addEventListener("click", async () => {
        try {
            await navigator.clipboard.writeText(location.origin + path);
            status.textContent = "Link copied. Open dλsociate from the Home Screen and paste it under Following.";
        } catch { status.textContent = "Use Share link to copy the thread link, then paste it in the Home Screen app."; }
    });

    save.addEventListener("click", async () => {
        if (saving) return;
        saving = save.disabled = remove.disabled = true;
        const selection = mode.value;
        const entry = item ? {...item, mode: selection} : {
            path, id: b64(crypto.getRandomValues(new Uint8Array(32))), title: client.thread.title, mode: selection,
        };
        try {
            if (selection !== "muted") {
                if (!supported || !client.pushKey) throw Error(hint || "Phone alerts are unavailable here. Choose Muted to save the thread.");
                if (!registration) {
                    await registrationTask;
                    throw Error("Tap Save again when the browser is ready to enable alerts.");
                }
                if (Notification.permission === "denied") throw Error("Allow notifications in browser settings or choose Muted.");
                // Call subscribe inside the click. iOS checks transient user
                // activation before asking the operating system for permission.
                if (!subscription) subscription = await registration.pushManager.subscribe({
                    userVisibleOnly: true, applicationServerKey: keyBytes(client.pushKey),
                });
            }
            // Save the capability locally before enabling delivery. If the
            // server fails, the local copy stays muted and can be retried.
            const previous = item;
            if (!previous) store({...entry, mode: "muted"});
            item ||= {...entry, mode: "muted"};
            if (selection !== "muted" || previous) {
                await request(endpoint(entry), "PUT", {mode: selection,
                    ...(selection !== "muted" ? {subscription: subscription.toJSON()} : {})});
            }
            item = entry;
            store(entry);
            status.textContent = selection === "muted" ? "Saved to Following. Alerts are muted." : "Saved. " + modeLabels[selection] + " alerts are on.";
        } catch (error) { status.textContent = error.message || "Could not save this follow."; }
        finally { saving = save.disabled = remove.disabled = false; showState(); }
    });

    remove.addEventListener("click", async () => {
        if (!item || saving) return;
        saving = save.disabled = remove.disabled = true;
        try {
            await removeFollow(item);
            item = null;
            status.textContent = "Removed from Following.";
        } catch (error) { status.textContent = error.message; }
        finally { saving = save.disabled = remove.disabled = false; showState(); }
    });
}
