/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {request} from "./thread-client.js";

export async function reviewAgreements(endpoint, wording) {
    const terms = wording || await request(endpoint);
    const dialog = document.createElement("dialog");
    dialog.className = "agreement-dialog";
    dialog.setAttribute("aria-labelledby", "agreement-title");
    dialog.innerHTML = `<h2 id="agreement-title"></h2>
      <div class="agreement-text" tabindex="0" role="region" aria-labelledby="agreement-title"></div>
      <p class="agreement-hint" role="status"></p>
      <div class="share-actions"><button type="button" data-decline>Decline</button>
      <button type="button" data-agree hidden>I agree</button></div>`;
    const title = dialog.querySelector("h2");
    const content = dialog.querySelector(".agreement-text");
    const hint = dialog.querySelector(".agreement-hint");
    const agree = dialog.querySelector("[data-agree]");
    const decline = dialog.querySelector("[data-decline]");
    const previousFocus = document.activeElement;
    let step = 0, accepted = false, saving = false;

    function revealAtEnd() {
        if (content.scrollTop + content.clientHeight + 2 >= content.scrollHeight && agree.hidden) {
            agree.hidden = false;
            hint.textContent = "";
        }
    }

    function showStep() {
        title.textContent = step === 0 ? "1 of 2 / License Agreement" : "2 of 2 / Karmic Law";
        content.textContent = step === 0 ? terms.license : terms.karmicLaw;
        agree.hidden = true;
        hint.textContent = "Read to the end to agree.";
        content.scrollTop = 0;
        content.focus();
        revealAtEnd();
    }

    return new Promise(resolve => {
        const resize = new ResizeObserver(revealAtEnd);
        dialog.addEventListener("close", () => {
            resize.disconnect();
            dialog.remove();
            if (previousFocus?.isConnected) previousFocus.focus();
            resolve(accepted);
        }, {once: true});
        dialog.addEventListener("cancel", event => { if (saving) event.preventDefault(); });
        content.addEventListener("scroll", revealAtEnd);
        decline.addEventListener("click", () => dialog.close());
        agree.addEventListener("click", async () => {
            if (agree.hidden || saving) return;
            if (step === 0) {
                step = 1;
                showStep();
                return;
            }
            saving = agree.disabled = decline.disabled = true;
            try {
                await request(endpoint, "POST", {version: terms.version, license: true, karmicLaw: true});
                accepted = true;
                dialog.close();
            } catch (error) {
                hint.textContent = error.message;
            } finally {
                saving = agree.disabled = decline.disabled = false;
            }
        });
        document.body.append(dialog);
        dialog.showModal();
        showStep();
        resize.observe(content);
    });
}
