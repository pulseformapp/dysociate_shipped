/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {
    authorForRoom, browserCookieName, browserCredential, digest, issueInvite, randomId, requestCredential,
    roomForCreation, sessionCookie, verifyInvite, codeVerifier, lockedCreationDigest, creationConsent,
} from "./identity.mjs";
import {inspectMedia, maxMediaRequest} from "./media.mjs";
import {checkSubscription, followPattern, modes, pushAvailable} from "./push.mjs";
import threadPage from "./web/thread.html";
import threadStyle from "./web/thread.css";
import threadClient from "./web/thread-client.js";
import threadView from "./web/thread-page.js";
import recorder from "./web/reel-recorder.js";
import createPage from "./web/create.html";
import createView from "./web/create-page.js";
import agreementView from "./web/agreements.js";
import followView from "./web/follow.js";
import followingPage from "./web/following.html";
import followingView from "./web/following.js";
import serviceWorker from "./web/push-sw.js";
import manifest from "./web/live.webmanifest";
import icon192 from "../dysociate_ios_web/dist/icon-192.png";
import icon512 from "../dysociate_ios_web/dist/icon-512.png";
import touchIcon from "../dysociate_ios_web/dist/icon-180.png";
import license from "./LICENSE";
export {LiveThread} from "./thread.mjs";
export {PushBudget} from "./push.mjs";

const headers = {
    "Cache-Control": "private, no-store",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
    "X-Robots-Tag": "noindex, nofollow, noarchive",
};
const encoder = new TextEncoder();
const maxRequestBytes = 32 * 1024;
const operationPattern = /^[A-Za-z0-9_-]{22,64}$/;
const postPattern = /^p_[A-Za-z0-9_-]{22}$/;
const threadRoute = /^\/api\/v1\/threads\/([^/]+)(?:\/(history|changes|live|posts|media|access|join|requests|handoff|claim|branch|target|reactions|like|agreement|follow)(?:\/([^/]+))?)?$/;
const karmicLaw = "If the app is used for nefarious purposes, the user acknowledges, agrees to, " +
    "and believes in the karmic repercussions that will be bestowed upon them.\n\n~ as above so below ~";
let versionPromise;
const agreementVersion = () => versionPromise ||= digest(JSON.stringify([license, karmicLaw]));
const assets = new Map([
    ["/t/_assets/thread.css", [threadStyle, "text/css"]],
    ["/t/_assets/thread-client.js", [threadClient, "text/javascript"]],
    ["/t/_assets/thread-page.js", [threadView, "text/javascript"]],
    ["/t/_assets/reel-recorder.js", [recorder, "text/javascript"]],
    ["/t/_assets/create-page.js", [createView, "text/javascript"]],
    ["/t/_assets/agreements.js", [agreementView, "text/javascript"]],
    ["/t/_assets/follow.js", [followView, "text/javascript"]],
    ["/t/_assets/following.js", [followingView, "text/javascript"]],
    ["/t/push-sw.js", [serviceWorker, "text/javascript"]],
    ["/t/live.webmanifest", [manifest, "application/manifest+json"]],
    ["/t/_assets/icon-192.png", [icon192, "image/png"]],
    ["/t/_assets/icon-512.png", [icon512, "image/png"]],
    ["/t/_assets/icon-180.png", [touchIcon, "image/png"]],
]);

class InvalidRequest extends Error {
    constructor(status, code, message, retryAfter) {
        super(message);
        this.status = status;
        this.code = code;
        this.retryAfter = retryAfter;
    }
}

const json = (payload, status = 200, extra = {}) => Response.json(payload, {status, headers: {...headers, ...extra}});
const error = (status, code, message, retryAfter) =>
    json({error: {code, message}}, status, retryAfter ? {"Retry-After": String(retryAfter)} : {});
const unavailable = () => error(404, "thread_unavailable", "This thread is unavailable.");
const invalid = message => new InvalidRequest(400, "invalid_input", message);

async function readBytes(request, limit) {
    if (!request.body) throw invalid("A request body is required.");
    const tooLarge = () => new InvalidRequest(413, "payload_too_large", "This request is too large.");
    if (Number(request.headers.get("Content-Length")) > limit) throw tooLarge();

    const bytes = new Uint8Array(limit);
    const reader = request.body.getReader();
    let length = 0;
    try {
        for (let chunk = await reader.read(); !chunk.done; chunk = await reader.read()) {
            if (length + chunk.value.byteLength > bytes.byteLength) {
                await reader.cancel().catch(() => {});
                throw tooLarge();
            }
            bytes.set(chunk.value, length);
            length += chunk.value.byteLength;
        }
    } finally {
        reader.releaseLock();
    }
    return bytes.subarray(0, length);
}

function parseJson(source) {
    let data;
    try {
        data = JSON.parse(source);
    } catch {
        throw invalid("A valid JSON object is required.");
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) throw invalid("A JSON object is required.");
    return data;
}

async function readJson(request) {
    if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get("Content-Type") || "")) {
        throw new InvalidRequest(415, "unsupported_content_type", "Send an application/json request.");
    }
    const bytes = await readBytes(request, maxRequestBytes);
    let source;
    try { source = new TextDecoder("utf-8", {fatal: true}).decode(bytes); }
    catch { throw invalid("A valid JSON object is required."); }
    return parseJson(source);
}

async function readPost(request, env) {
    const contentType = request.headers.get("Content-Type") || "";
    if (!/^multipart\/form-data(?:\s*;|$)/i.test(contentType)) return {data: await readJson(request)};
    if (env.ENABLE_MEDIA !== "true") throw new InvalidRequest(403, "media_disabled", "Attachments are unavailable here.");
    const bytes = await readBytes(request, maxMediaRequest);
    let form;
    try { form = await new Response(bytes, {headers: {"Content-Type": contentType}}).formData(); }
    catch { throw invalid("The attachment upload could not be read."); }
    const payload = form.get("payload");
    const file = form.get("media");
    if ([...form.keys()].length !== 2 || typeof payload !== "string" || encoder.encode(payload).length > maxRequestBytes ||
        !(file instanceof Blob)) throw invalid("Send one attachment and a post.");
    const media = await inspectMedia(file);
    if (media.status) throw new InvalidRequest(media.status, media.code, media.message);
    if (media.info.type === "video/mp4" && env.ENABLE_REELS !== "true") {
        throw new InvalidRequest(403, "reels_disabled", "Reels are unavailable here.");
    }
    return {data: parseJson(payload), media};
}

function text(value, label, limit, measure) {
    if (typeof value !== "string") throw invalid(label + " must be text.");
    const trimmed = value.trim();
    if (!trimmed || measure(trimmed) > limit) throw invalid(label + " is empty or too long.");
    return trimmed;
}

function ensureFields(data, supported) {
    if (Object.keys(data).some(field => !supported.includes(field))) {
        throw invalid("This request contains an unsupported field.");
    }
}

function sameOrigin(request, origin) {
    if (request.headers.get("Origin") !== origin) {
        throw new InvalidRequest(403, "origin_forbidden", "This request must come from the thread page.");
    }
}

function requireCredential(request, origin, env) {
    const credential = requestCredential(request, browserCookieName(request, env));
    if (!credential) throw new InvalidRequest(401, "session_required", "Start a local session to continue.");
    if (credential.client === "browser") sameOrigin(request, origin);
    else requireNativeTransport(request, env);
    return credential;
}

function requireNativeTransport(request, env) {
    // Browser writes carry Origin, including same-origin fetches with a
    // bearer header. Native clients use the existing originless API.
    if (webAgreements(env) && request.headers.has("Origin")) {
        throw new InvalidRequest(403, "browser_session_required", "Use the browser session to continue.");
    }
}

async function requireAllowance(request, limiter, action) {
    if (!limiter) return;
    // Cloudflare sets the client address on incoming requests. Keep it in
    // the edge limiter and out of the thread's database and response.
    const key = action + ":" + (request.headers.get("CF-Connecting-IP") || "unknown");
    if (!(await limiter.limit({key})).success) {
        throw new InvalidRequest(429, "rate_limited", "Too many requests. Wait a minute and try again.", 60);
    }
}

function requireWrites(env) {
    if (env.PAUSE_WRITES === "true") {
        throw new InvalidRequest(503, "writes_paused", "Live posting is temporarily paused. Try again in a minute.", 60);
    }
}

function operationId(value) {
    if (typeof value !== "string" || !operationPattern.test(value)) throw invalid("A valid operation ID is required.");
    return value;
}

function postFields(data, media) {
    return {
        body: media && typeof data.body === "string" && !data.body.trim() ? "" :
            text(data.body, "Post", 4096, value => encoder.encode(value).byteLength),
        displayName: data.displayName === undefined ? "Guest" :
            text(data.displayName, "Display name", 48, value => Array.from(value).length),
    };
}

function passkey(value) {
    if (typeof value !== "string" || value.trim().length < 8 || encoder.encode(value.trim()).length > 128) {
        throw invalid("Enter a passkey of at least 8 characters and at most 128 UTF-8 bytes.");
    }
    return value.trim();
}

function cursor(url, field, minimum) {
    const input = url.searchParams.get(field);
    const value = Number(input);
    if (!input || !/^\d+$/.test(input) || !Number.isSafeInteger(value) || value < minimum) {
        throw new InvalidRequest(400, "invalid_cursor", "Use a valid thread cursor.");
    }
    return value;
}

async function session(request, env, origin) {
    const data = await readJson(request);
    ensureFields(data, ["client", "creation"]);
    if (data.creation !== undefined && (data.client !== "browser" || data.creation !== true)) {
        throw invalid("The creation session is available to browsers.");
    }
    if (data.client === "native") {
        requireNativeTransport(request, env);
        await requireAllowance(request, env.SESSION_RATE, "session");
        return json({credential: randomId(32)}, 201);
    }
    if (data.client !== "browser") throw invalid("Choose browser or native as the client.");
    sameOrigin(request, origin);
    const cookieName = browserCookieName(request, env);
    const existing = browserCredential(request, cookieName);
    if (!existing) await requireAllowance(request, env.SESSION_RATE, "session");
    const token = existing || randomId(32);
    return json(data.creation ? {identity: await digest("browser-create/v1/" + token)} : {}, 200, {
        "Set-Cookie": cookieName + "=" + token + "; Path=/;"
            + (cookieName === sessionCookie ? " Secure;" : "") + " HttpOnly; SameSite=Strict; Max-Age=31536000",
    });
}

function threadStub(env, roomId) {
    return env.THREADS.get(env.THREADS.idFromName(roomId));
}

function callThread(thread, action, data, media) {
    const body = JSON.stringify(data);
    return thread.fetch("https://thread.internal/" + action, {
        method: "POST",
        headers: {"Content-Type": media ? "application/octet-stream" : "application/json"},
        body: media ? new Blob([body, "\n", media.bytes]) : body,
    });
}

const webAgreements = env => env.ENABLE_WEB_AGREEMENTS === "true";

function agreementCookieName(request, env) {
    return browserCookieName(request, env) + "-create-consent";
}

async function canCreate(request, env, credential) {
    if (!webAgreements(env) || credential.client !== "browser") return true;
    const name = agreementCookieName(request, env) + "=";
    const cookie = (request.headers.get("Cookie") || "").split(";")
        .map(part => part.trim()).find(part => part.startsWith(name))?.slice(name.length);
    return Boolean(cookie && await creationConsent(env, credential.token, await agreementVersion(), cookie));
}

async function acceptAgreements(request) {
    const data = await readJson(request);
    ensureFields(data, ["version", "license", "karmicLaw"]);
    const version = await agreementVersion();
    if (data.version !== version || data.license !== true || data.karmicLaw !== true)
        throw new InvalidRequest(409, "agreements_changed", "Open the agreements again to review the current wording.");
    return version;
}

async function browserAgreements(request, env, origin) {
    const token = browserCredential(request, browserCookieName(request, env));
    if (!token) return error(401, "session_required", "Start a local session to continue.");
    if (request.method === "GET") {
        return json({required: webAgreements(env), accepted: await canCreate(request, env, {token, client: "browser"}),
            version: await agreementVersion(), license, karmicLaw});
    }
    sameOrigin(request, origin);
    await requireAllowance(request, env.SESSION_RATE, "agreements");
    const version = await acceptAgreements(request);
    const name = agreementCookieName(request, env);
    const cookie = await creationConsent(env, token, version);
    return json({accepted: true}, 200, {"Set-Cookie": name + "=" + cookie + "; Path=/;" +
        (name.startsWith("__Host-") ? " Secure;" : "") + " HttpOnly; SameSite=Strict; Max-Age=31536000"});
}

async function create(request, env, origin) {
    const credential = requireCredential(request, origin, env);
    if (credential.client === "browser" && env.ENABLE_BROWSER_CREATE !== "true") {
        throw new InvalidRequest(403, "browser_create_disabled", "Create new threads from the dλsociate app.");
    }
    if (!await canCreate(request, env, credential))
        return error(403, "agreements_required", "Agree to the License Agreement and Karmic Law before creating a thread.");
    requireWrites(env);
    await requireAllowance(request, env.CREATE_RATE, "create");

    const {data, media} = await readPost(request, env);
    ensureFields(data, ["operationId", "title", "openingPost", "accessMode", "passkey"]);
    if (data.accessMode !== undefined && !["locked", "wild-west"].includes(data.accessMode)) throw invalid("Choose Wild West or Locked.");
    const locked = data.accessMode === "locked";
    if (locked && env.ENABLE_LOCKED !== "true") {
        throw new InvalidRequest(403, "locked_disabled", "Locked threads are unavailable on this service.");
    }
    if (!locked && data.passkey !== undefined) throw invalid("Only a locked thread can have a passkey.");
    const code = data.passkey === undefined ? undefined : passkey(data.passkey);
    const id = operationId(data.operationId);
    if (!data.openingPost || typeof data.openingPost !== "object" || Array.isArray(data.openingPost)) {
        throw invalid("An opening post is required.");
    }
    ensureFields(data.openingPost, ["body", "displayName"]);
    const title = text(data.title, "Title", 120, value => Array.from(value).length);
    const openingPost = postFields(data.openingPost, media);
    const roomId = await roomForCreation(credential.token, id);
    const inviteKeyId = env.ACTIVE_INVITE_KEY_ID;
    const content = {title, openingPost, mediaHash: media?.hash, mediaType: media?.info.type};
    const [authorId, requestDigest, newInvite, verifier] = await Promise.all([
        authorForRoom(credential.token, roomId),
        locked ? lockedCreationDigest(credential.token, {...content, code}) : digest(JSON.stringify(content)),
        issueInvite(env, inviteKeyId, roomId, locked),
        code === undefined ? undefined : codeVerifier(env, inviteKeyId, roomId, code),
    ]);
    const result = await callThread(threadStub(env, roomId), "create", {
        roomId, authorId, operationId: id, title, openingPost, requestDigest, inviteKeyId, media: media?.info,
        locked, codeVerifier: verifier,
        agreementVersion: webAgreements(env) && credential.client === "browser" ? await agreementVersion() : undefined,
    }, media);
    const record = await result.json();
    if (!result.ok) return json(record, result.status);

    // The first successful request fixes the invitation version for this
    // operation. Replays return the same link even after a key rotation.
    const {inviteKeyId: originalKeyId, ...payload} = record;
    const invite = originalKeyId === inviteKeyId ? newInvite : await issueInvite(env, originalKeyId, roomId, locked);
    return json({...payload, shareUrl: new URL("/t/" + invite, origin).href}, result.status);
}

async function handleThread(request, env, url, origin, [, invite, action, postId]) {
    const invitation = await verifyInvite(env, invite);
    if (!invitation) return unavailable();
    const {roomId, keyId, locked} = invitation;
    const thread = threadStub(env, roomId);
    const credential = requestCredential(request, browserCookieName(request, env));
    const actorId = credential ? await authorForRoom(credential.token, roomId) : null;
    const actor = {actorId, locked};
    const grouped = url.searchParams.get("view") === "groups";
    let result;
    if (request.method === "GET" && !action) {
        result = await callThread(thread, "snapshot", {...actor, grouped,
            agreementVersion: grouped && webAgreements(env) ? await agreementVersion() : undefined});
        if (result.ok && (grouped || env.ENABLE_MEDIA === "true")) {
            return json({...await result.json(),
                ...(grouped ? {agreementsRequired: webAgreements(env), pushKey: pushAvailable(env) && env.PAUSE_PUSH !== "true"
                    ? env.PUSH_VAPID_PUBLIC_KEY : null} : {}),
                ...(env.ENABLE_MEDIA === "true" ? {media: {photos: true, reels: env.ENABLE_REELS === "true"}} : {})});
        }
    } else if (["GET", "HEAD"].includes(request.method) && action === "media" && postPattern.test(postId || "")) {
        result = await thread.fetch("https://thread.internal/media/" + postId, {
            method: request.method, headers: {Range: request.headers.get("Range") || "", "X-Actor": actorId || "", "X-Locked": String(locked)},
        });
        if (request.method === "HEAD" && !result.ok) {
            return new Response(null, {status: result.status, headers});
        }
        return new Response(result.body, {status: result.status, headers: {
            ...Object.fromEntries(result.headers), ...headers, "Cross-Origin-Resource-Policy": "same-origin",
        }});
    } else if (request.method === "GET" && !postId && action === "history") {
        result = await callThread(thread, "history", {...actor, grouped, before: cursor(url, "before", 1)});
    } else if (request.method === "GET" && ["branch", "target"].includes(action) && postPattern.test(postId || "")) {
        result = await callThread(thread, action, {...actor, postId,
            ...(action === "branch" ? {after: cursor(url, "after", 0)} : {})});
    } else if (request.method === "GET" && action === "reactions" && !postId) {
        const postIds = [...new Set((url.searchParams.get("ids") || "").split(","))];
        if (postIds.length > 50 || postIds.some(id => !postPattern.test(id))) throw invalid("Choose up to 50 posts.");
        result = await callThread(thread, "reactions", {...actor, postIds});
    } else if (request.method === "PUT" && action === "like" && postPattern.test(postId || "")) {
        requireCredential(request, origin, env);
        requireWrites(env);
        await requireAllowance(request, env.POST_RATE, "like");
        const data = await readJson(request);
        ensureFields(data, ["liked", "actorRevision", "operationId"]);
        if (typeof data.liked !== "boolean" || !Number.isSafeInteger(data.actorRevision) || data.actorRevision < 0)
            throw invalid("Choose a valid Like state and revision.");
        result = await callThread(thread, "like", {...actor, postId, liked: data.liked,
            actorRevision: data.actorRevision, operationId: operationId(data.operationId)});
    } else if (action === "follow" && followPattern.test(postId || "")) {
        if (credential?.client !== "browser") return error(401, "session_required", "Open the thread in your browser.");
        if (request.method === "GET") {
            result = await callThread(thread, "follow", {...actor, followId: postId, mode: "status"});
        } else if (request.method === "PUT" || request.method === "DELETE") {
            sameOrigin(request, origin);
            await requireAllowance(request, env.SESSION_RATE, "follow");
            const data = request.method === "DELETE" ? {mode: "remove"} : await readJson(request);
            ensureFields(data, ["mode", "subscription"]);
            if (request.method === "PUT" && !modes.includes(data.mode)) throw invalid("Choose a notification mode.");
            let subscription;
            if (["replies", "all"].includes(data.mode)) {
                if (!pushAvailable(env) || env.PAUSE_PUSH === "true")
                    return error(503, "push_unavailable", "Phone notifications are paused. You can still save this thread to Following.");
                try { subscription = await checkSubscription(data.subscription); }
                catch { throw invalid("The browser notification subscription is invalid or uses an unsupported provider."); }
            }
            result = await callThread(thread, "follow", {...actor, followId: postId, mode: data.mode, subscription});
        } else return error(404, "not_found", "This operation is unavailable.");
    } else if (action === "agreement" && !postId) {
        if (request.method === "GET") {
            // Wording is public. The acceptance write below still checks admission.
            return json({version: await agreementVersion(), license, karmicLaw});
        }
        if (request.method !== "POST") return error(404, "not_found", "This operation is unavailable.");
        requireCredential(request, origin, env);
        await requireAllowance(request, env.SESSION_RATE, "thread-agreement");
        result = await callThread(thread, "agreement", {...actor, agreementVersion: await acceptAgreements(request)});
    } else if (request.method === "GET" && !postId && action === "changes") {
        result = await callThread(thread, "changes", {...actor, grouped, after: cursor(url, "after", 0)});
    } else if (request.method === "GET" && !postId && action === "live") {
        requireCredential(request, origin, env);
        if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
            return error(426, "upgrade_required", "Open a WebSocket to receive live updates.");
        }
        const upstream = new Request("https://thread.internal/live", request);
        upstream.headers.set("X-Actor", actorId);
        upstream.headers.set("X-Locked", String(locked));
        upstream.headers.set("X-Grouped", String(grouped));
        result = await thread.fetch(upstream);
        if (result.status === 101) return result;
    } else if (request.method === "POST" && !postId && action === "posts") {
        requireCredential(request, origin, env);
        requireWrites(env);
        await requireAllowance(request, env.POST_RATE, "post");
        const {data, media} = await readPost(request, env);
        ensureFields(data, ["operationId", "body", "displayName", "parentId"]);
        const id = operationId(data.operationId);
        const parentId = data.parentId ?? null;
        if (parentId !== null && (typeof parentId !== "string" || !postPattern.test(parentId))) throw invalid("Choose a valid reply target.");
        const post = {...postFields(data, media), parentId};
        const requestDigest = await digest(JSON.stringify({...post, mediaHash: media?.hash, mediaType: media?.info.type}));
        result = await callThread(thread, "post", {...post, ...actor, grouped, requestDigest, operationId: id, media: media?.info,
            agreementVersion: webAgreements(env) && credential.client === "browser" ? await agreementVersion() : undefined}, media);
    } else if (request.method === "DELETE" && action === "posts" && postPattern.test(postId || "")) {
        requireCredential(request, origin, env);
        requireWrites(env);
        await requireAllowance(request, env.POST_RATE, "delete");
        result = await callThread(thread, "delete", {...actor, grouped, postId});
    } else if (locked && request.method === "GET" && !postId && ["access", "requests"].includes(action)) {
        if (action === "requests" && !actorId) return error(401, "session_required", "Start a local session to continue.");
        result = await callThread(thread, action, actor);
    } else if (locked && request.method === "POST" && ["join", "requests", "handoff", "claim"].includes(action)) {
        result = await changeAccess(request, env, origin, thread, actor, invitation, invite, action, postId);
    } else {
        return error(404, "not_found", "This operation is unavailable.");
    }
    const retryAfter = result.headers.get("Retry-After");
    return json(await result.json(), result.status, retryAfter ? {"Retry-After": retryAfter} : {});
}

async function changeAccess(request, env, origin, thread, actor, {keyId, roomId}, invite, action, id) {
    const credential = requireCredential(request, origin, env);
    requireWrites(env);
    await requireAllowance(request, env.POST_RATE, "access-" + action);
    const data = await readJson(request);
    if (action === "join" && !id) {
        ensureFields(data, ["name", "passkey"]);
        const name = text(data.name ?? "Guest", "Display name", 48, value => Array.from(value).length);
        if (data.passkey !== undefined) await requireAllowance(request, env.SESSION_RATE, "passkey");
        const verifier = data.passkey === undefined ? undefined : await codeVerifier(env, keyId, roomId, passkey(data.passkey));
        return callThread(thread, "join", {...actor, name, verifier});
    }
    if (action === "requests" && /^[A-Za-z0-9_-]{22}$/.test(id || "")) {
        ensureFields(data, ["decision"]);
        if (!["approved", "declined"].includes(data.decision)) throw invalid("Choose Approve or Decline.");
        return callThread(thread, "decision", {...actor, id, decision: data.decision});
    }
    if (action === "handoff" && !id && credential.client === "native") {
        ensureFields(data, []);
        const token = randomId(32);
        const result = await callThread(thread, "handoff", {...actor, digest: await digest(token)});
        return result.ok ? Response.json({creatorUrl: new URL("/t/" + invite + "#creator=" + token, origin).href}) : result;
    }
    if (action === "claim" && !id && credential.client === "browser") {
        ensureFields(data, ["token"]);
        if (!/^[A-Za-z0-9_-]{43}$/.test(data.token || "")) throw invalid("This creator link is invalid.");
        return callThread(thread, "claim", {...actor, digest: await digest(data.token)});
    }
    return error(404, "not_found", "This operation is unavailable.");
}

function page(content, origin) {
    return new Response(content, {headers: {
        ...headers,
        "Content-Type": "text/html; charset=utf-8",
        "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' blob:; " +
            "media-src 'self' blob:; worker-src 'self'; manifest-src 'self'; connect-src 'self' " +
            origin.replace(/^http/, "ws") + "; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    }});
}

export default {
    async fetch(request, env) {
        const url = new URL(request.url);
        const origin = env.PUBLIC_ORIGIN || url.origin;
        const {pathname: path} = url;
        try {
            if (request.method === "GET" && path === "/api/v1/health") return new Response(null, {status: 204, headers});
            if (request.method === "POST" && path === "/api/v1/session") return await session(request, env, origin);
            if (["GET", "POST"].includes(request.method) && path === "/api/v1/agreements")
                return await browserAgreements(request, env, origin);
            if (request.method === "POST" && path === "/api/v1/threads") return await create(request, env, origin);
            const match = threadRoute.exec(path);
            if (match) return await handleThread(request, env, url, origin, match);
            if (request.method === "GET" && assets.has(path)) {
                const [content, type] = assets.get(path);
                return new Response(content, {headers: {...headers, "Content-Type": type.startsWith("image/") ? type : type + "; charset=utf-8"}});
            }
            if (request.method === "GET" && path === "/t/following") return page(followingPage, origin);
            if (request.method === "GET" && path === "/t/new" && env.ENABLE_BROWSER_CREATE === "true") {
                return page(createPage.replace('data-locked="off"',
                    env.ENABLE_LOCKED === "true" ? 'data-locked="on"' : 'data-locked="off"'), origin);
            }
            if (request.method === "GET" && path.startsWith("/t/")) {
                if (!await verifyInvite(env, path.slice(3))) return unavailable();
                return page(threadPage, origin);
            }
            return error(404, "not_found", "This operation is unavailable.");
        } catch (problem) {
            if (problem instanceof InvalidRequest) return error(problem.status, problem.code, problem.message, problem.retryAfter);
            return error(503, "service_unavailable", "The live service is temporarily unavailable. Try again.");
        }
    },
};
