/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import {readFile, writeFile} from "node:fs/promises";

const [mode, receiptFile] = process.argv.slice(2);
assert.ok(["seed", "paused", "restored"].includes(mode) && receiptFile, "Specify a pilot test mode and a local receipt file.");
const origin = "https://dysociate-live-pilot.pulseform.workers.dev";

async function call(path, method = "GET", payload, credential) {
    const headers = {};
    if (credential) headers.Authorization = "Bearer " + credential;
    if (payload !== undefined) headers["Content-Type"] = "application/json";
    const response = await fetch(origin + path, {
        method, headers, body: payload === undefined ? undefined : JSON.stringify(payload),
        redirect: "error", signal: AbortSignal.timeout(8000),
    });
    return {
        status: response.status,
        headers: response.headers,
        body: response.headers.get("content-type")?.includes("application/json") ? await response.json() : await response.text(),
    };
}

const health = await call("/api/v1/health");
assert.equal(health.status, 204);
assert.match(health.headers.get("cache-control"), /no-store/);

if (mode === "seed") {
    const session = await call("/api/v1/session", "POST", {client: "native"});
    assert.equal(session.status, 201);
    const credential = session.body.credential;
    const payload = {operationId: randomUUID(), title: "dλsociate HTTPS pilot", openingPost: {
        body: "This is a test thread. Tap Reply and send a short test message.",
    }};
    const created = await call("/api/v1/threads", "POST", payload, credential);
    assert.equal(created.status, 201);
    const other = await call("/api/v1/threads", "POST", {...payload, operationId: randomUUID()}, credential);
    assert.equal(other.status, 201);
    const link = new URL(created.body.shareUrl);
    assert.equal(link.origin, origin);
    const api = "/api/v1/threads/" + link.pathname.slice(3);
    const page = await call(link.pathname);
    assert.equal(page.status, 200);
    assert.match(page.body, /id="composer"/);
    assert.equal(page.headers.get("referrer-policy"), "no-referrer");
    const post = {operationId: randomUUID(), body: "The pilot retained this write across the rollback.", parentId: created.body.post.id};
    assert.equal((await call(api + "/posts", "POST", post)).status, 401);
    assert.equal((await call(api + "/posts", "POST", {...post, parentId: other.body.post.id}, credential)).status, 404);
    assert.equal((await call(api + "/live")).status, 401);
    const tampered = link.pathname.slice(0, -1) + (link.pathname.endsWith("A") ? "Q" : "A");
    assert.equal((await call(tampered)).status, 404);
    await writeFile(receiptFile, JSON.stringify({credential, payload, api, link: link.href, post}), {flag: "wx"});
    console.log("PASS HTTPS health, signed invitation, unauthenticated writes and socket rejection, and cross-thread isolation");
} else {
    const {credential, payload, api, link, post} = JSON.parse(await readFile(receiptFile, "utf8"));
    const snapshot = await call(api);
    assert.equal(snapshot.status, 200);
    assert.equal(snapshot.body.posts[0].body, payload.openingPost.body);
    const posted = await call(api + "/posts", "POST", post, credential);
    if (mode === "paused") {
        assert.equal(posted.status, 503);
        assert.equal(posted.body.error.code, "writes_paused");
        assert.equal(posted.headers.get("retry-after"), "60");
        assert.equal((await call(api)).body.headSeq, snapshot.body.headSeq);
        console.log("PASS pilot history remains readable during a 503 write pause");
    } else {
        assert.equal(posted.status, 201);
        const retry = await call(api + "/posts", "POST", post, credential);
        assert.equal(retry.status, 200);
        assert.deepEqual(retry.body, posted.body);
        const prior = await call("/api/v1/threads", "POST", payload, credential);
        assert.equal(prior.status, 200);
        assert.equal(prior.body.shareUrl, link);
        console.log("PASS rollback retained history, restored writes, and kept the same invitation and receipts");
        console.log(link);
    }
}
