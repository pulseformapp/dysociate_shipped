/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */

import {encodeDigest} from "./identity.mjs";

export const mediaLimits = Object.freeze({"image/jpeg": 1024 * 1024, "image/png": 1024 * 1024, "video/mp4": 4 * 1024 * 1024});
export const mediaQuota = 32 * 1024 * 1024;
export const reelSeconds = 30;
export const maxMediaRequest = mediaLimits["video/mp4"] + 48 * 1024;

function malformed() {
    throw new RangeError("Invalid media container.");
}

function png(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (bytes.length < 45 || view.getUint32(0) !== 0x89504e47 || view.getUint32(4) !== 0x0d0a1a0a ||
        view.getUint32(8) !== 13 || view.getUint32(12) !== 0x49484452 ||
        view.getUint32(bytes.length - 8) !== 0x49454e44) malformed();
    return [view.getUint32(16), view.getUint32(20)];
}

function jpeg(bytes) {
    if (bytes[0] !== 0xff || bytes[1] !== 0xd8 ||
        bytes.at(-2) !== 0xff || bytes.at(-1) !== 0xd9) malformed();
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let offset = 2;
    while (offset + 4 < bytes.length && bytes[offset] === 0xff) {
        const marker = bytes[++offset];
        if (marker === 0xff) continue;
        offset++;
        const length = view.getUint16(offset);
        if (length < 2 || offset + length > bytes.length || marker === 0xda) break;
        if ([0xc0, 0xc1, 0xc2].includes(marker) && length >= 8) {
            return [view.getUint16(offset + 5), view.getUint16(offset + 3)];
        }
        offset += length;
    }
    malformed();
}

function mp4Duration(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const u32 = at => view.getUint32(at);
    const u64 = at => {
        const value = Number(view.getBigUint64(at));
        if (!Number.isSafeInteger(value)) malformed();
        return value;
    };
    const code = at => u32(at);
    // Read only direct children. This avoids recursively trusting arbitrary
    // container nesting or scanning through compressed media payloads.
    function* boxes(start, end) {
        let count = 0;
        while (start < end) {
            if (++count > 4096 || end - start < 8) malformed();
            const size = u32(start);
            const header = size === 1 ? 16 : 8;
            if (end - start < header) malformed();
            const length = size === 1 ? u64(start + 8) : size || end - start;
            if (length < header || length > end - start) malformed();
            yield {kind: code(start + 4), start: start + header, end: start + length};
            start += length;
        }
    }
    const children = box => [...boxes(box.start, box.end)];
    const kind = name => [...name].reduce((value, letter) => value * 256 + letter.charCodeAt(0), 0);
    const ofType = (list, name) => list.filter(box => box.kind === kind(name));
    const one = (list, name) => {
        const found = ofType(list, name);
        if (found.length !== 1) malformed();
        return found[0];
    };
    const bounded = (box, at, length) => {
        if (at + length > box.end) malformed();
        return at;
    };
    const full = box => u32(bounded(box, box.start, 4));
    const elapsed = box => {
        const version = full(box) >>> 24;
        if (version > 1) malformed();
        const offset = box.start + (version ? 20 : 12);
        const scale = u32(bounded(box, offset, version ? 12 : 8));
        const ticks = version ? u64(offset + 4) : u32(offset + 4);
        if (!scale) malformed();
        return {scale, ticks};
    };
    const roots = [...boxes(0, bytes.length)];
    one(roots, "ftyp");
    if (!ofType(roots, "mdat").some(box => box.end > box.start)) malformed();
    const movie = children(one(roots, "moov"));
    const header = elapsed(one(movie, "mvhd"));
    const tracks = new Map();
    let seconds = header.ticks / header.scale;
    let video = false;
    for (const track of ofType(movie, "trak")) {
        const fields = children(track);
        const tkhd = one(fields, "tkhd");
        const version = full(tkhd) >>> 24;
        if (version > 1) malformed();
        const id = u32(bounded(tkhd, tkhd.start + (version ? 20 : 12), 4));
        const lengthAt = bounded(tkhd, tkhd.start + (version ? 28 : 20), version ? 8 : 4);
        const trackLength = version ? u64(lengthAt) : u32(lengthAt);
        seconds = Math.max(seconds, trackLength / header.scale);
        // Edit lists can insert empty time before playback or repeat a segment.
        for (const edits of ofType(fields, "edts")) {
            const list = one(children(edits), "elst");
            const version = full(list) >>> 24;
            if (version > 1) malformed();
            const count = u32(bounded(list, list.start + 4, 4));
            const width = version ? 20 : 12;
            if (count > 128) malformed();
            bounded(list, list.start + 8, count * width);
            let length = 0;
            for (let i = 0; i < count; i++) {
                const entry = list.start + 8 + i * width;
                length += version ? u64(entry) : u32(entry);
            }
            seconds = Math.max(seconds, length / header.scale);
        }
        const media = children(one(fields, "mdia"));
        const timing = elapsed(one(media, "mdhd"));
        const handler = one(media, "hdlr");
        const handlerType = code(bounded(handler, handler.start + 8, 4));
        if (tracks.has(id) || tracks.size >= 2 || ![kind("vide"), kind("soun")].includes(handlerType)) malformed();
        const samples = children(one(children(one(media, "minf")), "stbl"));
        const descriptions = one(samples, "stsd");
        const entries = [...boxes(bounded(descriptions, descriptions.start, 8) + 8, descriptions.end)];
        if (entries.length !== 1) malformed();
        if (handlerType === kind("vide")) {
            if (video || ![kind("avc1"), kind("avc3")].includes(entries[0].kind)) malformed();
            video = true;
        } else if (entries[0].kind !== kind("mp4a")) malformed();
        const sampleTime = one(samples, "stts");
        const count = u32(bounded(sampleTime, sampleTime.start, 8) + 4);
        let ticks = 0;
        if (count > 6000) malformed();
        for (let i = 0; i < count; i++) {
            const at = bounded(sampleTime, sampleTime.start + 8 + i * 8, 8);
            ticks += u32(at) * u32(at + 4);
        }
        seconds = Math.max(seconds, timing.ticks / timing.scale, ticks / timing.scale);
        tracks.set(id, {scale: timing.scale, end: ticks, isVideo: handlerType === kind("vide")});
    }
    const fragmentDefaults = new Map();
    for (const mvex of ofType(movie, "mvex")) {
        for (const trex of ofType(children(mvex), "trex")) {
            const at = bounded(trex, trex.start, 24);
            fragmentDefaults.set(u32(at + 4), u32(at + 12));
        }
    }
    let samplesRead = 0;
    for (const fragment of ofType(roots, "moof")) {
        for (const traf of ofType(children(fragment), "traf")) {
            const parts = children(traf);
            const tfhd = one(parts, "tfhd");
            const flags = full(tfhd);
            const id = u32(bounded(tfhd, tfhd.start + 4, 4));
            const track = tracks.get(id);
            if (!track) malformed();
            let at = tfhd.start + 8 + ((flags & 1) ? 8 : 0) + ((flags & 2) ? 4 : 0);
            const duration = (flags & 8) ? u32(bounded(tfhd, at, 4)) : fragmentDefaults.get(id);
            const decodeTime = ofType(parts, "tfdt")[0];
            let end = track.end;
            if (decodeTime) {
                const version = full(decodeTime) >>> 24;
                if (version > 1) malformed();
                at = bounded(decodeTime, decodeTime.start + 4, version ? 8 : 4);
                end = version ? u64(at) : u32(at);
            }
            for (const run of ofType(parts, "trun")) {
                const flags = full(run);
                const count = u32(bounded(run, run.start + 4, 4));
                samplesRead += count;
                if (samplesRead > 12_000) malformed();
                const stride = ((flags & 0x100) ? 4 : 0) + ((flags & 0x200) ? 4 : 0) +
                    ((flags & 0x400) ? 4 : 0) + ((flags & 0x800) ? 4 : 0);
                at = run.start + 8 + ((flags & 1) ? 4 : 0) + ((flags & 4) ? 4 : 0);
                bounded(run, at, count * stride);
                for (let i = 0; i < count; i++, at += stride) {
                    const span = (flags & 0x100) ? u32(at) : duration;
                    if (!span) malformed();
                    if (flags & 0x800) {
                        const composition = (flags >>> 24) === 1 ? view.getInt32(at + stride - 4) : u32(at + stride - 4);
                        seconds = Math.max(seconds, (end + composition + span) / track.scale);
                    }
                    end += span;
                }
            }
            track.end = Math.max(track.end, end);
            seconds = Math.max(seconds, track.end / track.scale);
        }
    }
    if (!video || ![...tracks.values()].some(track => track.isVideo && track.end > 0) ||
        !Number.isFinite(seconds) || seconds <= 0) malformed();
    return seconds;
}

export async function inspectMedia(file) {
    const type = file.type.toLowerCase();
    if (!Object.hasOwn(mediaLimits, type)) return {status: 415, code: "media_type", message: "Choose a JPEG or PNG photo, or record an MP4 reel."};
    if (!file.size || file.size > mediaLimits[type]) return {status: 413, code: "media_size", message: "Photos can be up to 1 MiB and reels up to 4 MiB."};
    const bytes = new Uint8Array(await file.arrayBuffer());
    let duration;
    try {
        if (type === "video/mp4") duration = mp4Duration(bytes);
        else {
            const [width, height] = type === "image/png" ? png(bytes) : jpeg(bytes);
            if (width < 1 || height < 1 || width > 4096 || height > 4096 || width * height > 12_000_000) malformed();
        }
    } catch (problem) {
        if (!(problem instanceof RangeError)) throw problem;
        return {status: 422, code: "invalid_media", message: "This attachment could not be read. Choose a different photo or retake the reel."};
    }
    if (duration > reelSeconds) return {status: 422, code: "reel_duration", message: "Record a reel of 30 seconds or less."};
    return {bytes, info: {type, size: bytes.length, ...(duration === undefined ? {} : {duration})}, hash: await encodeDigest(bytes)};
}
