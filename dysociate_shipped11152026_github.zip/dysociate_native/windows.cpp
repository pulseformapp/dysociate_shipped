/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "composer.h"

#include <algorithm>
#include <vector>

namespace {
using namespace dysociate;

constexpr wchar_t class_name[] = L"DysociateNativeComposer";
constexpr COLORREF background = RGB(12, 7, 20);
constexpr UINT_PTR poll_timer = 1;
constexpr int more_id = 102;
constexpr int copy_id = 103;
// Action 1 queues creation. Action 2 returns the draft for advanced options.
using Submit = int (__cdecl*)(int, const wchar_t*, const wchar_t*);
using Poll = int (__cdecl*)(wchar_t*, int);
using LinkAction = int (__cdecl*)(int);

struct Composer {
    HWND controls[FieldCount]{};
    HFONT font{};
    HBRUSH field_brush{};
    HBRUSH backdrop{};
    int dpi{};
    Submit submit{};
    Poll poll{};
    LinkAction link_action{};
    Screen screen = Screen::Draft;
    bool busy = false;
    int result = 0;
};

void set_busy(Composer& composer, bool busy) {
    composer.busy = busy;
    EnableWindow(composer.controls[Create], !busy);
    EnableWindow(composer.controls[Cancel], !busy);
    EnableWindow(composer.controls[More], !busy);
    for (auto field : {Title, Body}) {
        SendMessageW(composer.controls[field], EM_SETREADONLY, busy, 0);
    }
}

void set_status(Composer& composer, const wchar_t* status) {
    SetWindowTextW(composer.controls[Status], status);
    NotifyWinEvent(EVENT_OBJECT_NAMECHANGE, composer.controls[Status], OBJID_CLIENT, CHILDID_SELF);
}

std::vector<wchar_t> read_edit(HWND control) {
    std::vector<wchar_t> text(static_cast<std::size_t>(GetWindowTextLengthW(control)) + 1);
    GetWindowTextW(control, text.data(), static_cast<int>(text.size()));
    return text;
}

void position(HWND window, Composer& composer, int width) {
    const auto ui = layout(width, composer.dpi / 96.0f, composer.screen);
    for (int i = 0; i < FieldCount; ++i) {
        const auto r = ui.fields[i];
        if (composer.controls[i]) MoveWindow(composer.controls[i], r.x, r.y, r.width, r.height, TRUE);
    }
    InvalidateRect(window, nullptr, FALSE);
}

LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM command, LPARAM param) {
    if (message == WM_NCCREATE) {
        const auto create = reinterpret_cast<CREATESTRUCTW*>(param);
        SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(create->lpCreateParams));
    }
    auto* composer = reinterpret_cast<Composer*>(GetWindowLongPtrW(window, GWLP_USERDATA));
    if (!composer) return DefWindowProcW(window, message, command, param);
    switch (message) {
        case WM_DRAWITEM: {
            // The button is a real Win32 control for keyboard and AT. Its
            // owner-draw handler supplies the surface and visible focus.
            const auto item = reinterpret_cast<DRAWITEMSTRUCT*>(param);
            const bool primary = item->CtlID == IDOK;
            auto rectangle = item->rcItem;
            const bool disabled = item->itemState & ODS_DISABLED;
            SetDCBrushColor(item->hDC, primary && !disabled ? RGB(207, 141, 255) : RGB(23, 13, 37));
            FillRect(item->hDC, &rectangle, static_cast<HBRUSH>(GetStockObject(DC_BRUSH)));
            if (item->itemState & (ODS_FOCUS | ODS_SELECTED)) {
                InflateRect(&rectangle, -3, -3);
                DrawFocusRect(item->hDC, &rectangle);
            }
            wchar_t label[32]{};
            GetWindowTextW(item->hwndItem, label, 32);
            SetBkMode(item->hDC, TRANSPARENT);
            SetTextColor(item->hDC, primary && !disabled ? RGB(12, 7, 20) : RGB(245, 238, 255));
            auto old_font = SelectObject(item->hDC, composer->font);
            DrawTextW(item->hDC, label, -1, &rectangle, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
            SelectObject(item->hDC, old_font);
            return TRUE;
        }
        case WM_COMMAND:
            if (composer->screen == Screen::Link && HIWORD(command) == BN_CLICKED) {
                switch (LOWORD(command)) {
                    case IDOK:
                        set_status(*composer, composer->link_action(1) ? L"Opening live viewer…"
                                                                       : L"Could not open the viewer. Try Copy link.");
                        return 0;
                    case copy_id:
                        set_status(*composer, composer->link_action(2) ? L"Link copied."
                                                                       : L"Could not copy. Select the URL to copy it.");
                        return 0;
                    case more_id:
                        composer->result = 2;
                        DestroyWindow(window);
                        return 0;
                }
            }
            if ((LOWORD(command) == IDOK || LOWORD(command) == more_id) && HIWORD(command) == BN_CLICKED) {
                if (composer->busy) return 0;
                const bool create = LOWORD(command) == IDOK;
                // Start the UI timer before handing the draft to the service.
                // Worker threads report through poll(), never through HWNDs.
                if (create && !SetTimer(window, poll_timer, 60, nullptr)) {
                    set_status(*composer, L"Could not start creation. Try again.");
                    return 0;
                }
                try {
                    const auto title = read_edit(composer->controls[Title]);
                    const auto body = read_edit(composer->controls[Body]);
                    if (composer->submit(create ? 1 : 2, title.data(), body.data())) {
                        if (create) {
                            set_busy(*composer, true);
                            set_status(*composer, L"Creating live thread…");
                        } else {
                            composer->result = 2;
                            DestroyWindow(window);
                        }
                        return 0;
                    }
                } catch (const std::bad_alloc&) {
                    // Keep the existing edit controls and allow another try.
                }
                KillTimer(window, poll_timer);
                set_status(*composer, create ? L"Could not start creation. Try again."
                                             : L"Could not open options. Try again.");
                return 0;
            }
            if (LOWORD(command) == IDCANCEL) {
                if (!composer->busy) DestroyWindow(window);
                return 0;
            }
            break;
        case WM_TIMER: {
            if (command != poll_timer) break;
            wchar_t status[768]{};
            const int result = composer->poll(status, 768);
            if (result == 0) return 0;
            KillTimer(window, poll_timer);
            if (result > 0) {
                composer->result = 1;
                DestroyWindow(window);
            } else {
                set_busy(*composer, false);
                set_status(*composer, status);
                SetFocus(composer->controls[Create]);
            }
            return 0;
        }
        case WM_CLOSE:
            if (!composer->busy) DestroyWindow(window);
            return 0;
        case WM_CTLCOLORSTATIC:
        case WM_CTLCOLOREDIT: {
            auto dc = reinterpret_cast<HDC>(command);
            SetTextColor(dc, RGB(245, 238, 255));
            const auto control = reinterpret_cast<HWND>(param);
            const bool edit = control == composer->controls[Title] || control == composer->controls[Body];
            SetBkColor(dc, edit ? RGB(23, 13, 37) : background);
            return reinterpret_cast<LRESULT>(edit ? composer->field_brush : composer->backdrop);
        }
        case WM_ERASEBKGND:
            return 1;  // WM_PAINT covers the entire client area in one blit.
        case WM_PAINT: {
            PAINTSTRUCT paint_state{};
            const HDC dc = BeginPaint(window, &paint_state);
            RECT client{};
            GetClientRect(window, &client);
            const int width = client.right, height = client.bottom;
            if (width > 0 && height > 0 && width <= max_width && height <= max_height) {
                try {
                    std::vector<std::uint32_t> pixels(static_cast<std::size_t>(width) * height);
                    paint(pixels.data(), width, height, width, composer->dpi / 96.0f, composer->screen);
                    BITMAPINFO bitmap{};
                    bitmap.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
                    bitmap.bmiHeader.biWidth = width;
                    bitmap.bmiHeader.biHeight = -height;
                    bitmap.bmiHeader.biPlanes = 1;
                    bitmap.bmiHeader.biBitCount = 32;
                    bitmap.bmiHeader.biCompression = BI_RGB;
                    StretchDIBits(dc, 0, 0, width, height, 0, 0, width, height, pixels.data(),
                                  &bitmap, DIB_RGB_COLORS, SRCCOPY);
                } catch (const std::bad_alloc&) {
                    FillRect(dc, &client, composer->backdrop);
                }
            } else {
                FillRect(dc, &client, composer->backdrop);
            }
            EndPaint(window, &paint_state);
            return 0;
        }
    }
    return DefWindowProcW(window, message, command, param);
}
int show(HWND parent, const wchar_t* title, const wchar_t* body, const wchar_t* notice, Composer& composer) {
    const HINSTANCE instance = GetModuleHandleW(nullptr);
    WNDCLASSW wc{};
    wc.lpfnWndProc = window_proc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.lpszClassName = class_name;
    if (!RegisterClassW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return -1;

    composer.dpi = parent ? GetDpiForWindow(parent) : GetDpiForSystem();
    if (composer.dpi == 0) composer.dpi = 96;
    constexpr DWORD style = WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_CLIPCHILDREN;
    const int width = MulDiv(520, composer.dpi, 96);
    RECT bounds{0, 0, width, layout(width, composer.dpi / 96.0f, composer.screen).height};
    AdjustWindowRectExForDpi(&bounds, style, FALSE, WS_EX_CONTROLPARENT, composer.dpi);
    const int outer_width = bounds.right - bounds.left, outer_height = bounds.bottom - bounds.top;
    MONITORINFO monitor{sizeof(MONITORINFO)};
    if (!GetMonitorInfoW(MonitorFromWindow(parent, MONITOR_DEFAULTTOPRIMARY), &monitor)) return -1;
    const auto work = monitor.rcWork;
    if (outer_width > work.right - work.left || outer_height > work.bottom - work.top) return -1;
    const HWND window = CreateWindowExW(WS_EX_CONTROLPARENT, class_name,
        composer.screen == Screen::Draft ? L"dλsociate · Live composer" : L"dλsociate · Thread ready",
        style, work.left + std::max<int>(0, (work.right - work.left - outer_width) / 2),
        work.top + std::max<int>(0, (work.bottom - work.top - outer_height) / 2),
        outer_width, outer_height, parent, nullptr, instance, &composer);
    if (!window) return -1;
    composer.font = CreateFontW(-MulDiv(12, composer.dpi, 72), 0, 0, 0, FW_NORMAL,
        FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, FIXED_PITCH, L"Consolas");
    composer.field_brush = CreateSolidBrush(RGB(23, 13, 37));
    composer.backdrop = CreateSolidBrush(background);
    bool controls_ready = true;
    const auto child = [&](Field field, LPCWSTR type, LPCWSTR name, DWORD flags, int id = 0) {
        const HWND control = CreateWindowW(type, name, WS_CHILD | WS_VISIBLE | flags,
            0, 0, 0, 0, window, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), instance, nullptr);
        composer.controls[field] = control;
        controls_ready = controls_ready && control;
        SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(composer.font), FALSE);
    };
    const bool draft = composer.screen == Screen::Draft;
    child(Heading, L"STATIC", draft ? L"Create live thread" : L"Thread ready", SS_CENTERIMAGE);
    if (draft) {
        child(TitleLabel, L"STATIC", L"&Thread title", SS_CENTERIMAGE);
        child(Title, L"EDIT", title, WS_TABSTOP | ES_AUTOHSCROLL, 100);
        child(BodyLabel, L"STATIC", L"&Opening post", SS_CENTERIMAGE);
        child(Body, L"EDIT", body, WS_TABSTOP | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN, 101);
    } else {
        child(TitleLabel, L"STATIC", title, SS_LEFT | SS_NOPREFIX | SS_ENDELLIPSIS);
        child(BodyLabel, L"STATIC", L"Thread link", SS_CENTERIMAGE);
        child(Body, L"EDIT", body, WS_TABSTOP | ES_READONLY | ES_AUTOHSCROLL, 101);
    }
    child(Status, L"STATIC", notice, SS_LEFT | SS_NOPREFIX);
    if (!draft) {
        child(Create, L"BUTTON", L"Open link", WS_TABSTOP | BS_OWNERDRAW, IDOK);
        child(Copy, L"BUTTON", L"Copy link", WS_TABSTOP | BS_OWNERDRAW, copy_id);
    }
    child(More, L"BUTTON", draft ? L"More options" : L"Manage thread", WS_TABSTOP | BS_OWNERDRAW, more_id);
    child(Cancel, L"BUTTON", draft ? L"Cancel" : L"Done", WS_TABSTOP | BS_OWNERDRAW, IDCANCEL);
    if (draft) child(Create, L"BUTTON", L"Create thread", WS_TABSTOP | BS_OWNERDRAW, IDOK);
    if (!controls_ready) {
        composer.result = -1;
        DestroyWindow(window);
    } else {
        position(window, composer, width);
        const bool enable_parent = parent && IsWindowEnabled(parent);
        if (enable_parent) EnableWindow(parent, FALSE);
        ShowWindow(window, SW_SHOW);
        SetFocus(composer.controls[draft ? Title : Create]);
        MSG message{};
        while (IsWindow(window)) {
            const int state = GetMessageW(&message, nullptr, 0, 0);
            if (state <= 0) {
                DestroyWindow(window);
                if (state == 0) PostQuitMessage(static_cast<int>(message.wParam));
                break;
            }
            if (message.message == WM_KEYDOWN && message.wParam == VK_ESCAPE
                    && (message.hwnd == window || IsChild(window, message.hwnd))) {
                if (!composer.busy) DestroyWindow(window);
                continue;
            }
            if (!IsDialogMessageW(window, &message)) {
                TranslateMessage(&message);
                DispatchMessageW(&message);
            }
        }
        if (enable_parent) {
            EnableWindow(parent, TRUE);
            SetActiveWindow(parent);
        }
    }
    DeleteObject(composer.font);
    DeleteObject(composer.field_brush);
    DeleteObject(composer.backdrop);
    return composer.result;
}
}  // namespace

// Each call owns a modal window. Only the draft window polls for network
// completion. The finished link is passed in by the platform client.
extern "C" __declspec(dllexport) int __cdecl DysociateComposeThreadWithOptions(
    HWND parent, const wchar_t* title, const wchar_t* body, const wchar_t* notice, Submit submit, Poll poll) {
    Composer composer{};
    composer.submit = submit;
    composer.poll = poll;
    return show(parent, title, body, notice, composer);
}

extern "C" __declspec(dllexport) int __cdecl DysociateShowThreadLink(
    HWND parent, const wchar_t* title, const wchar_t* url, LinkAction action) {
    Composer composer{};
    composer.screen = Screen::Link;
    composer.link_action = action;
    return show(parent, title, url, L"Anyone with the link can read and reply.", composer);
}
