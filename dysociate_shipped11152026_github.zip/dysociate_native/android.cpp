/* Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
 */
#include <android/bitmap.h>
#include <jni.h>
#include <cmath>

#include "composer.h"

namespace {
bool valid(int width, float scale) {
    return width > 0 && width <= dysociate::max_width && std::isfinite(scale) && scale > 0 && scale <= 5;
}

dysociate::Screen screen_for(jboolean result) {
    return result ? dysociate::Screen::LinkWithShare : dysociate::Screen::Draft;
}
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_lunasoft_dysociate_NativeComposer_geometry(JNIEnv* env, jclass, jint width, jfloat scale, jboolean link_screen) {
    if (!valid(width, scale)) return nullptr;
    const auto layout = dysociate::layout(width, scale, screen_for(link_screen));
    std::array<jint, 1 + 4 * dysociate::FieldCount> coordinates{};
    coordinates[0] = layout.height;
    int index = 1;
    for (const auto& rect : layout.fields) {
        coordinates[index++] = rect.x;
        coordinates[index++] = rect.y;
        coordinates[index++] = rect.width;
        coordinates[index++] = rect.height;
    }
    auto result = env->NewIntArray(coordinates.size());
    if (result) env->SetIntArrayRegion(result, 0, coordinates.size(), coordinates.data());
    return result;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_lunasoft_dysociate_NativeComposer_render(JNIEnv* env, jclass, jobject bitmap, jfloat scale, jboolean result) {
    AndroidBitmapInfo info{};
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS
        || info.format != ANDROID_BITMAP_FORMAT_RGBA_8888 || !valid(info.width, scale)
        || info.height == 0 || info.height > dysociate::max_height) return JNI_FALSE;
    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS) return JNI_FALSE;
    const int stride = info.stride / sizeof(std::uint32_t);
    auto* words = static_cast<std::uint32_t*>(pixels);
    dysociate::paint(words, info.width, info.height, stride, scale, screen_for(result));
    // GDI consumes little-endian BGRA words. Android's bitmap expects RGBA.
    for (unsigned y = 0; y < info.height; ++y) {
        for (unsigned x = 0; x < info.width; ++x) {
            auto& word = words[y * stride + x];
            word = (word & 0xff00ff00) | ((word >> 16) & 0xff) | ((word & 0xff) << 16);
        }
    }
    AndroidBitmap_unlockPixels(env, bitmap);
    return JNI_TRUE;
}
